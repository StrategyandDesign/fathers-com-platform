#!/usr/bin/env python3
"""Page generator for the Fathers.com static platform. Shared chrome, per-page bodies."""
import os
import re

# Absolute base URL for share cards and canonical links.
# CHANGE THIS ONE LINE if the site moves to a custom domain (e.g. https://www.fathers.com).
SITE_URL = "https://fathers-com-platform.vercel.app"
OG_IMAGE = SITE_URL + "/assets/img/og-image.jpg"

# v4.0 reposition flags (ADR-4: rollout is a data change, not a redesign).
# SHOW_MILITARY dark-launches the entire veteran surface: pages are not generated,
# routes are removed from nav and footers, and stale generated files are deleted.
# Flipping this back to True restores the vertical after a copy pass.
SHOW_MILITARY = False
MILITARY_PAGES = {
    'veterans.html', 'veterans-hub.html', 'veterans-start.html', 'veterans-checkin.html',
    'veterans-module.html', 'veterans-resources.html', 'voice.html', 'share.html',
}

# Private / transactional pages: keep them out of Google's index. Everything else is indexable.
NOINDEX = {'report.html', 'organizations.html', 'share.html', 'account.html', 'plan.html', 'circles.html', 'player.html', 'checkout.html', 'enroll.html', 'login.html', 'veterans-hub.html', 'veterans-start.html', 'veterans-checkin.html', 'voice.html', 'find-a-program.html', 'classes.html', 'veterans-resources.html'}


def _esc(s):
    """Escape for an HTML attribute without breaking entities that are already there (e.g. &middot;)."""
    s = re.sub(r'&(?!#?\w+;)', '&amp;', s)
    return s.replace('"', '&quot;').replace('<', '&lt;').replace('>', '&gt;')


def social_meta(fname, title, desc):
    """Open Graph + Twitter card + canonical + app icon + robots, per page."""
    url = SITE_URL + "/" + fname
    ttl = _esc(title + " | Fathers.com")
    ds = _esc(desc)
    robots = '<meta name="robots" content="noindex,follow">\n' if fname in NOINDEX else ''
    return (
        robots
        + f'<link rel="canonical" href="{url}">\n'
        + '<link rel="apple-touch-icon" href="assets/img/apple-touch-icon.png">\n'
        + '<meta name="theme-color" content="#000000">\n'
        + '<meta property="og:type" content="website">\n'
        + '<meta property="og:site_name" content="Fathers.com">\n'
        + f'<meta property="og:title" content="{ttl}">\n'
        + f'<meta property="og:description" content="{ds}">\n'
        + f'<meta property="og:url" content="{url}">\n'
        + f'<meta property="og:image" content="{OG_IMAGE}">\n'
        + '<meta property="og:image:width" content="1200">\n'
        + '<meta property="og:image:height" content="630">\n'
        + '<meta property="og:image:alt" content="Fathers.com, know where you stand as a father">\n'
        + '<meta name="twitter:card" content="summary_large_image">\n'
        + f'<meta name="twitter:title" content="{ttl}">\n'
        + f'<meta name="twitter:description" content="{ds}">\n'
        + f'<meta name="twitter:image" content="{OG_IMAGE}">'
    )

HEAD = '''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title} | Fathers.com</title>
<meta name="description" content="{desc}">
<link rel="icon" type="image/png" href="assets/img/favicon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Poppins:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
<script>document.documentElement.dataset.theme={THEME};</script>
<link rel="stylesheet" href="assets/css/forge.css">
{meta}
</head>
<body>
'''

def nav(active='', mode='public'):
    if mode=='app':
        links = [('Home','plan.html'),('The Courses','certificates.html'),('Stories','stories.html'),('Circles','circles.html')]
        active = {'Certificates':'The Courses','Classes':'The Courses'}.get(active, active)
    else:
        links = [('The Profile','profile.html'),('The Courses','certificates.html'),('Stories','stories.html')]
        # Legacy page actives map onto the new public nav so highlighting stays sane.
        active = {'For Groups':'For Organizations','For Veterans':'For Organizations','Classes':'The Courses','Certificates':'The Courses','My Plan':'Home'}.get(active, active)
    lis = ''.join(f'<li><a href="{h}" {"class=\"active\"" if t==active else ""}>{t}</a></li>' for t,h in links)
    right = ('<a href="sponsor.html" class="hide-m">Sponsor</a><a href="login.html" class="hide-m">Log in</a><a class="btn btn-yellow btn-sm" href="profile.html">Start your Profile</a>'
             if mode=='public' else
             '<a href="#" data-open-search class="hide-m">Search</a><a href="sponsor.html" class="hide-m">Sponsor</a><a href="account.html" class="avatarchip" title="Account" style="text-decoration:none">M</a>')
    return f'''<nav class="nav"><div class="container nav-inner">
<a class="brand" href="index.html"><img class="lg-dark" src="assets/img/logomark-light.png" alt="Fathers.com logomark"><img class="lg-light" src="assets/img/logomark-dark.png" alt="Fathers.com logomark"><b>Fathers.com</b></a>
<ul class="nav-links">{lis}</ul>
<div class="nav-right">{right}<button class="themeswitch" data-themeswitch aria-label="Switch palette" title="Switch palette"><span class="tsw-dot"></span></button><button class="nav-toggle">MENU</button></div>
</div></nav>
'''

FOOT = '''<footer><div class="container">
<div class="footgrid">
  <div><a class="brand" href="index.html" style="margin-bottom:16px"><img class="lg-dark" src="assets/img/logomark-light.png" alt="" style="height:34px"><img class="lg-light" src="assets/img/logomark-dark.png" alt="" style="height:34px"><b>Fathers.com</b></a>
    <p class="small" style="margin-top:14px;max-width:32ch">Presence is a skill. Train it.</p>
    <p class="fine" style="margin-top:14px">PO Box 996, Tontitown, AR 72770<br>Team@Fathers.com</p></div>
  <div><h4>Measure</h4><ul><li><a href="profile.html">The Keystone Profile</a></li><li><a href="research.html">The Research</a></li></ul></div>
  <div><h4>Train &amp; Prove</h4><ul><li><a href="stories.html">Stories</a></li><li><a href="certificates.html">The Courses</a></li><li><a href="verify.html">Verify a credential</a></li></ul></div>
  <div><h4>Certification</h4><ul><li><a href="organizations.html">Certified Organizations</a></li><li><a href="facilitators.html">Certified Facilitators</a></li><li><a href="groups.html">Groups &amp; Circles</a></li><li><a href="employers.html">Employers</a></li><li><a href="sponsor.html">Sponsor a Man</a></li></ul></div>
  <div><h4>Company</h4><ul><li><a href="about.html">About NCF</a></li><li><a href="research.html">Research</a></li><li><a href="gatherings.html">Gatherings</a></li><li><a href="mailto:Team@Fathers.com">Contact</a></li></ul></div>
  <div><h4>Legal</h4><ul><li><a href="terms.html">Terms</a></li><li><a href="privacy.html">Privacy</a></li><li><a href="security.html">Security</a></li><li><a href="verify.html">Verify a credential</a></li></ul></div>
</div>
<div style="margin-top:48px;max-width:420px"><h4 style="font-family:var(--font-mono);font-size:11px;letter-spacing:.18em;text-transform:uppercase;color:var(--ash);margin-bottom:12px">One useful thing for fathers, weekly</h4>
<form class="row" data-lead="newsletter" data-done="You are on the list. One useful thing, weekly."><input class="input" name="email" type="email" required placeholder="Email address"><button class="btn btn-secondary btn-sm">Send it</button></form></div>
<div class="footbottom"><span class="fine">Fathers.com is a program of the National Center for Fathering, a 501(c)(3) nonprofit.</span><span class="fine">© <span data-year></span> National Center for Fathering</span></div>
</div></footer>
<script src="assets/js/config.js"></script>
<script src="assets/js/supabase-client.js"></script>
<script src="assets/js/roles.js"></script>
<script src="assets/js/app.js"></script>
'''

PAGES = {}

# ================================================== index.html (P1)
PAGES['index.html'] = dict(title='Know where you stand', desc='Take the free Keystone Profile. Four scores, one honest read, and a ninety-day plan built for you. Two tracks: Fatherhood and Manhood. About twenty minutes.', active='', mode='public', body='''
<header class="hero"><div class="container split">
  <div>
    <div class="eyebrow" style="margin-bottom:18px">FATHERS.COM</div>
    <h1 class="d-48" style="font-weight:700;letter-spacing:-.02em">Know where you stand.</h1>
    <p class="lead" style="margin:22px 0 28px">Start with the free Keystone Profile. Get your score on the four things that matter, and a ninety-day plan built for you. Two tracks, one standard: The Fatherhood Track for men raising children now, The Manhood Track for men preparing, mentoring, or growing.</p>
    <div class="hero-intent">
      <div class="hero-intent-q">Where are you in the journey?</div>
      <div class="hero-intent-opts">
        <button class="hero-intent-opt" data-path="father">
          <span class="hio-text">
            <span class="hio-label">I'm raising children now</span>
            <span class="hio-sub">The Fatherhood Track</span>
          </span>
          <span class="hio-arrow">&rarr;</span>
        </button>
        <button class="hero-intent-opt" data-path="preparing">
          <span class="hio-text">
            <span class="hio-label">I'm preparing, mentoring, or growing</span>
            <span class="hio-sub">The Manhood Track</span>
          </span>
          <span class="hio-arrow">&rarr;</span>
        </button>
      </div>
      <div class="hero-intent-foot">
        <span class="fine">Free. About twenty minutes. Your results are private.</span>
        <a class="link ash" href="certificates.html" style="font-size:13px">Or explore classes first</a>
      </div>
    </div>
  </div>
  <div class="heromarquee" aria-hidden="true">
    <div class="hm-col hm-col-a">
      <div class="hm-track">
        <figure class="hm-card"><img src="assets/img/photos/hero-01.jpg" alt=""></figure>
        <figure class="hm-card"><img src="assets/img/photos/hero-03.jpg" alt=""></figure>
        <figure class="hm-card"><img src="assets/img/photos/hero-05.jpg" alt=""></figure>
        <figure class="hm-card"><img src="assets/img/photos/testimonial-01.jpg" alt=""></figure>
        <figure class="hm-card"><img src="assets/img/photos/hero-07.jpg" alt=""></figure>
        <figure class="hm-card"><img src="assets/img/photos/hero-01.jpg" alt=""></figure>
        <figure class="hm-card"><img src="assets/img/photos/hero-03.jpg" alt=""></figure>
        <figure class="hm-card"><img src="assets/img/photos/hero-05.jpg" alt=""></figure>
        <figure class="hm-card"><img src="assets/img/photos/testimonial-01.jpg" alt=""></figure>
      </div>
    </div>
    <div class="hm-col hm-col-b">
      <div class="hm-track hm-track-slow">
        <figure class="hm-card"><img src="assets/img/photos/hero-02.jpg" alt=""></figure>
        <figure class="hm-card"><img src="assets/img/photos/hero-06.jpg" alt=""></figure>
        <figure class="hm-card"><img src="assets/img/photos/hero-04.jpg" alt=""></figure>
        <figure class="hm-card"><img src="assets/img/photos/hero-02.jpg" alt=""></figure>
        <figure class="hm-card"><img src="assets/img/photos/hero-06.jpg" alt=""></figure>
        <figure class="hm-card"><img src="assets/img/photos/hero-04.jpg" alt=""></figure>
      </div>
    </div>
  </div>
</div></header>

<section class="band"><div class="container split">
  <div>
    <div class="eyebrow" style="margin-bottom:14px">MEASURE &middot; YOUR BASELINE</div>
    <h2 class="d-36">Four things decide the kind of father you are.</h2>
    <p style="color:var(--ash);margin:18px 0 28px;max-width:52ch">Involvement. Consistency. Awareness. Nurturance. The Keystone Father Profile measures all four, normed against 9,232 fathers. You get a score, an honest read on where you stand, and a ninety-day plan built from your gaps. Free, before you pay for anything.</p>
    <a class="btn btn-yellow" href="profile.html">Start your Profile</a>
  </div>
  <div class="card" style="padding:32px">
    <div class="eyebrow" style="margin-bottom:16px">THE FOUR DIMENSIONS</div>
    <div class="bigscore" style="font-size:72px;margin-bottom:24px">71</div>
    <div class="domain"><div class="row1"><span>Involvement</span><span class="score">78</span></div><div class="bar"><span style="width:78%"></span></div></div>
    <div class="domain gap"><div class="row1"><span>Consistency</span><span class="score">55</span></div><div class="bar"><span style="width:55%"></span></div></div>
    <div class="domain"><div class="row1"><span>Awareness</span><span class="score">74</span></div><div class="bar"><span style="width:74%"></span></div></div>
    <div class="domain" style="margin-bottom:0"><div class="row1"><span>Nurturance</span><span class="score">77</span></div><div class="bar"><span style="width:77%"></span></div></div>
  </div>
</div></section>

<section class="band tight" id="start-free"><div class="container split" style="align-items:start">
  <div>
    <div class="eyebrow" style="margin-bottom:12px">START FREE</div>
    <h2 style="font-family:var(--font-ui);font-weight:600;font-size:22px;margin-bottom:22px">Start free. Grow on a plan.</h2>
    <div class="row wrap"><a class="btn btn-yellow" href="profile.html">Start your Profile</a><a class="btn btn-secondary" href="sponsor.html">Sponsor a man</a></div>
    <p class="fine" style="margin-top:12px">Every course is free to the man who takes it. Sponsorship funds seats and materials inside certified programs. The completion is still his to earn.</p>
  </div>
  <div class="stack-16">
    <div class="check"><span class="checkmark">&check;</span><span>Your Keystone Profile and ninety-day plan, free</span></div>
    <div class="check"><span class="checkmark">&check;</span><span>Dr. Canfield's Fundamentals of Fathering, free</span></div>
    <div class="check"><span class="checkmark">&check;</span><span>Classes taught by fathers who lived it</span></div>
    <div class="check"><span class="checkmark">&check;</span><span>A Certificate of Completion when you finish the work, at no cost</span></div>
    <div class="check"><span class="checkmark">&check;</span><span>Full class library membership, optional</span></div>
    <div class="check"><span class="checkmark">&check;</span><span>30-day money-back guarantee on anything paid</span></div>
  </div>
</div></section>

<section><div class="container">
  <div class="billboard">
    <a class="slot r-21x9 play-overlay filled" data-slot="IMG-P1-BILL-01" href="class.html" aria-label="Watch The Fundamentals of Fathering"><img src="assets/img/photos/billboard-home.jpg" alt="A father with his son"><span class="tri"></span></a>
    <div class="overlay">
      <div class="eyebrow" style="margin-bottom:12px">TRAIN &middot; THE FLAGSHIP CLASS</div>
      <h2 class="d-36" style="margin:0 0 8px">The Fundamentals of Fathering</h2>
      <p class="small" style="margin-bottom:18px">The Keystone Profile grows out of the work of Dr. Ken Canfield, founder of the National Center for Fathering. Start with his flagship class on presence. Free.</p>
      <a class="btn btn-secondary play" href="class.html">Watch The Fundamentals</a>
    </div>
  </div>
</div></section>

<section class="tight"><div class="container">
  <div class="eyebrow" style="margin-bottom:12px">TRAIN &middot; YOUR PLAN</div>
  <h2 class="d-28" style="margin-bottom:12px">A plan you actually work.</h2>
  <p style="color:var(--ash);margin:0 0 24px;max-width:56ch">Your Profile becomes a ninety-day plan, one clear step at a time. New films and lessons every month, on the drive or on the couch. The Profile and your plan are always free.</p>
  <div class="grid-3" id="homeclasses" style="margin-top:6px">
    <a class="card" href="class.html" style="padding:0;overflow:hidden;text-decoration:none">
      <div class="slot r-2x3 filled" data-slot="IMG-P1-CAT-1" style="max-height:280px"><img src="assets/img/photos/action-01.jpg" alt="Fathering Fundamentals"></div>
      <div style="padding:20px 22px">
        <div class="row between" style="margin-bottom:8px"><span class="pill">FREE COURSE</span><span class="fine mono">5 sessions</span></div>
        <h3 style="margin-bottom:6px">Fathering Fundamentals</h3>
        <p class="fine" style="color:var(--ash)">The 7 Secrets of Effective Fathers, taught by Dr. Ken Canfield. Five sessions, usable the same night. Free to train; completion recognized.</p>
      </div>
    </a>
    <a class="card" href="certificates.html#waitlist" style="padding:0;overflow:hidden;text-decoration:none">
      <div class="slot r-2x3 filled" data-slot="IMG-P1-CAT-2" style="max-height:280px"><img src="assets/img/photos/action-02.jpg" alt="Steady Under Pressure"></div>
      <div style="padding:20px 22px">
        <div class="row between" style="margin-bottom:8px"><span class="pill" style="opacity:.75">IN DEVELOPMENT</span><span class="fine mono">Waitlist</span></div>
        <h3 style="margin-bottom:6px">Steady Under Pressure</h3>
        <p class="fine" style="color:var(--ash)">A man&rsquo;s temper, trained. Join the waitlist and shape the first cohort.</p>
      </div>
    </a>
    <a class="card" href="certificates.html#waitlist" style="padding:0;overflow:hidden;text-decoration:none">
      <div class="slot r-2x3 filled" data-slot="IMG-P1-CAT-3" style="max-height:280px"><img src="assets/img/photos/community-01.jpg" alt="Coming Home Present"></div>
      <div style="padding:20px 22px">
        <div class="row between" style="margin-bottom:8px"><span class="pill" style="opacity:.75">IN DEVELOPMENT</span><span class="fine mono">Waitlist</span></div>
        <h3 style="margin-bottom:6px">Coming Home Present</h3>
        <p class="fine" style="color:var(--ash)">Presence after time away. Join the waitlist and shape the first cohort.</p>
      </div>
    </a>
  </div>
  <p style="margin-top:20px"><a class="link" href="certificates.html">See the three courses</a></p>
</div></section>

<section class="tight" style="padding:10px 0 34px"><div class="container">
  <div class="row wrap" style="gap:26px;justify-content:center;text-align:center">
    <span class="fine">Normed on 9,232 fathers</span><span class="fine ash">&middot;</span><span class="fine">Built by the National Center for Fathering since 1990</span><span class="fine ash">&middot;</span><span class="fine">Every credential publicly verifiable</span>
  </div>
</div></section>

<section class="band-brass"><div class="container split">
  <div>
    <div class="eyebrow brass" style="margin-bottom:14px">PROVE &middot; THE CERTIFICATE OF COMPLETION</div>
    <h2 class="d-36" style="font-size:32px">Proof you did the work.</h2>
    <p style="color:var(--ash);margin:16px 0 26px;max-width:50ch">Verified hours, checkpoints passed, a final at eighty percent, and a serial any court, program, or employer can confirm online. Signed by Dr. Ken Canfield and the Certified Facilitator who led your cohort. Free to every man who earns it.</p>
    <a class="btn btn-secondary" href="certificates.html">See the Certificate</a>
    <p class="fine" style="margin-top:16px">Run a program? Become a Certified Organization and your facilitators present these at completion. <a class="link ash" href="organizations.html" style="font-size:12px">Get certified</a>.</p>
  </div>
  <div class="card brass-card">
    <div class="row" style="gap:20px">
      <div class="slot r-1x1 filled" data-slot="IMG-P0-CARD-03" style="flex:0 0 84px"><img src="assets/img/photos/hero-05.jpg" alt="A father"></div>
      <div><h3 style="margin-bottom:6px">Certificate of Completion &middot; Fathering Fundamentals</h3>
        <div class="mono small">10.0 verified hours</div>
        <div class="mono fine" style="margin-top:8px">FC-2026-000000</div></div>
    </div>
  </div>
</div></section>





<section><div class="container split">
  <div>
    <div class="eyebrow" style="margin-bottom:14px">GATHERINGS</div>
    <h2 class="d-36" style="font-size:32px">We gather fathers in real life.</h2>
    <p style="color:var(--ash);margin:16px 0 26px;max-width:52ch">The work is not only on a screen. Fathers.com hosts gatherings that bring men, mentors, and the people who lead them into the same room. Get notified about a gathering near you.</p>
  </div>
  <div>
    <a class="btn btn-secondary" href="gatherings.html">See gatherings</a>
    <p class="fine" style="margin-top:12px">One or two flagship events to start. Bring one to your city.</p>
  </div>
</div></section>

<section class="tight"><div class="container center" style="max-width:760px">
  <p class="quote">"I stopped guessing. I had a baseline and a plan, and my kids felt the difference in a month."</p>
  <div class="row" style="justify-content:center;margin-top:24px"><div class="slot r-1x1 filled" data-slot="IMG-P1-TST-01" style="width:44px;border-radius:50%"><img src="assets/img/photos/testimonial-01.jpg" alt="Marcus"></div><span class="small">Marcus, father of three, Circle member</span></div>
  <div class="row" style="justify-content:center;gap:8px;margin-top:22px"><span class="dot on"></span><span class="dot"></span><span class="dot"></span></div>
</div></section>

<section><div class="container" style="max-width:820px">
  <div class="eyebrow" style="margin-bottom:12px">QUESTIONS</div>
  <h2 class="d-28" style="margin-bottom:24px">Frequently asked questions</h2>
  <details open><summary>What is Fathers.com?</summary><div class="body">Fathers.com is the home of the Keystone Standard, from the National Center for Fathering. Men measure where they stand and complete the courses free. NCF certifies the organizations and facilitators who lead them, and every man who finishes holds a Certificate of Completion anyone can verify. Programs and agencies use the same standard to show whether men are changing.</div></details>
<details><summary>Who gets certified?</summary><div class="body">Organizations and facilitators. An organization earns Certified status against a published standard. A facilitator earns the Certified Facilitator credential through training, an exam, and a supervised first cohort. The man who completes a course receives a Certificate of Completion: earned, serialed, signed, and free to him. Certification is the institutional layer. Completion is his.</div></details>
  <details><summary>How much does it cost?</summary><div class="body">For the man doing the work: nothing. The Keystone Profile, the ninety-day plan, the courses, and the Certificate of Completion are free. Organizations pay for certification and facilitator credentialing. A full class library membership is optional at $120 a year, with a 30-day money-back guarantee.</div></details>
  <details><summary>How does the Keystone Profile work?</summary><div class="body">About 40 questions, around twenty minutes. You get four domain scores, an overall baseline, and a plan built from your gaps, normed against 9,232 fathers. Your results are yours. We never share them.</div></details>
  <details><summary>Do you rate other programs?</summary><div class="body">Yes. We publish a standard for whether a father program works and rate programs against it, including our own, so fathers and funders can tell what actually helps. Tell us what you need and we will point you to one that fits.</div></details>
  <details><summary>Are the Certificates of Completion accepted by courts?</summary><div class="body">Each certificate carries verified hours, passed checkpoints, and a public verification page. Acceptance is decided by each court or program, so confirm with yours before enrolling.</div></details>
  <details><summary>Is this religious?</summary><div class="body">No. Faith is an optional lens you can switch on during the Profile. It changes which classes and actions we recommend. Nothing else.</div></details>
</div></section>
''')

# ================================================== profile.html (P2)
PAGES['report.html'] = dict(title='Your Written Report', desc='Every dimension: what it measures, where you stand, and your first moves.', active='', mode='public', body='''
<section class="tight" style="padding-top:36px"><div class="container">
  <div id="rpRoot">
    <div class="center" style="padding:80px 0">
      <div class="eyebrow" style="margin-bottom:12px">PREPARING YOUR REPORT</div>
      <p class="ash">One moment.</p>
    </div>
  </div>
</div></section>
<script src="assets/js/keystone-data.js"></script>
<script src="assets/js/keystone-full.js"></script>
<script src="assets/js/keystone-report.js"></script>
''')

PAGES['profile.html'] = dict(title='The Keystone Father Profile', desc='About twenty minutes. Four scores. One plan.', active='', mode='public', nochrome=True, body='''
<div id="ksIntro" style="max-width:680px;margin:0 auto;padding:64px 24px 40px;text-align:center">
  <div class="eyebrow" style="margin-bottom:16px">THE KEYSTONE PROFILE</div>
  <h1 class="d-36" style="margin-bottom:14px">Twenty minutes that shape the next ninety days.</h1>
  <p style="color:var(--ash);max-width:52ch;margin:0 auto 28px">One hundred twenty-eight questions, built and validated by the National Center for Fathering. You get your score on the four dimensions that decide the kind of father you are, measured against 9,232 fathers, and a ninety-day plan built from your answers.</p>
  <div class="row wrap" style="justify-content:center;gap:22px;margin-bottom:30px">
    <span class="fine">About twenty minutes</span><span class="fine ash">&middot;</span>
    <span class="fine">Pause anytime, every answer saves</span><span class="fine ash">&middot;</span>
    <span class="fine">Private. Your answers are never shown to anyone.</span>
  </div>
  <button class="btn btn-yellow" id="ksBegin" style="font-size:16px;padding:14px 34px">Begin the Profile</button>
  <p class="fine" style="margin-top:16px">Already started? It picks up right where you left off.</p>
</div>
<div class="assess" id="keystone" hidden></div>
<p class="center fine" style="padding:0 0 28px"><a class="link ash" href="index.html" style="font-size:12px">Back to Fathers.com</a></p>
<script>(function(){
  var intro=document.getElementById('ksIntro'), app=document.getElementById('keystone');
  function begin(){ intro.hidden=true; app.hidden=false; try{sessionStorage.setItem('ks_intro_done','1')}catch(_){} window.scrollTo(0,0); }
  var b=document.getElementById('ksBegin'); if(b) b.addEventListener('click', begin);
  try{ if(sessionStorage.getItem('ks_intro_done')==='1') begin(); }catch(_){}
})();</script>
''')

# ================================================== stories.html (P3)
PAGES['stories.html'] = dict(title='Stories', desc='Epic fatherhood films. Origin, crisis, the turn, the standard.', active='Stories', mode='public', body='''
<section class="tight" style="padding-top:48px"><div class="container">
  <div style="margin-bottom:22px">
    <h1 class="d-36" style="margin-bottom:6px">Fathers who did the work.</h1>
    <p class="small" style="color:var(--ash)">Origin, crisis, the turn, the standard. Every story ends with the step you can take.</p>
  </div>
  <div class="billboard">
    <a class="slot r-21x9 play-overlay filled" data-slot="IMG-P3-BILL-01" href="story.html" aria-label="Watch the story"><img src="assets/img/photos/billboard-stories.jpg" alt="A father at the kitchen table"><span class="tri"></span></a>
    <div class="overlay">
      <div class="eyebrow" style="margin-bottom:12px">STORIES</div>
      <h2 class="d-48" style="margin-bottom:8px">Home by Six</h2>
      <p class="small" style="margin-bottom:18px">A father who chose to be there, one ordinary evening at a time.</p>
      <div class="row"><a class="btn btn-secondary play" href="story.html">Watch</a><a class="btn btn-secondary" href="story.html">Trailer</a><span class="tag">24 min</span></div>
    </div>
  </div>
</div></section>

<section class="tight"><div class="container stack-32">
  <div><h2 style="font-family:var(--font-display);font-size:24px;margin-bottom:18px">After the Sentence</h2>
  <div class="rowscroll" data-repeat="4" data-prefix="IMG-P3-ROW2-" data-ratio="r-16x9" data-href="story.html"
    data-titles="Visitation Day|Eight Years, Every Letter|The First Pickup|Walking Papers"
    data-metas="22 min|19 min|25 min|20 min"></div></div>
  <div><h2 style="font-family:var(--font-display);font-size:24px;margin-bottom:18px">Starting Over</h2>
  <div class="rowscroll" data-repeat="4" data-prefix="IMG-P3-ROW3-" data-ratio="r-16x9" data-href="story.html"
    data-titles="Two Households|The Apology|Sundays at Noon|Step by Step"
    data-metas="20 min|17 min|23 min|19 min"></div></div>
  <div><h2 style="font-family:var(--font-display);font-size:24px;margin-bottom:18px">The First Year</h2>
  <div class="rowscroll" data-repeat="4" data-prefix="IMG-P3-ROW4-" data-ratio="r-16x9" data-href="story.html"
    data-titles="Night Shift|Three Weeks of Leave|The Carrier|What My Father Did"
    data-metas="16 min|18 min|15 min|22 min"></div></div>
</div></section>

<section class="band tight"><div class="container row between wrap">
  <h2 class="d-28">Every man in these films took the Profile.</h2>
  <a class="btn btn-yellow" href="profile.html">Get your baseline</a>
</div></section>
''')

# ================================================== story.html (P3 detail + submission)
PAGES['story.html'] = dict(title='Back to the Kitchen Table', desc='One father. Origin, crisis, the turn, the standard.', active='Stories', mode='public', body='''
<div class="slot r-21x9 flush filled" data-slot="IMG-P3-DET-01" style="max-height:62vh"><img src="assets/img/photos/hero-06.jpg" alt="Back to the kitchen table"></div>
<section class="tight"><div class="container" style="display:grid;grid-template-columns:1.4fr .9fr;gap:56px">
  <div>
    <h1 class="d-36">Back to the Kitchen Table</h1>
    <p class="small" style="margin:10px 0 30px">Ray M. Father of two. Three years away. All the way back.</p>
    <div class="stack-8">
      <div class="row between" style="padding:14px 16px;border:1px solid var(--ember);border-radius:8px"><span><b class="mono" style="margin-right:14px;color:var(--ember-hi)">00:00</b>Origin</span><span class="tag" style="color:var(--ember-hi)">PLAYING</span></div>
      <div class="row between" style="padding:14px 16px;border:1px solid var(--hairline);border-radius:8px"><span><b class="mono ash" style="margin-right:14px">06:40</b>Crisis</span></div>
      <div class="row between" style="padding:14px 16px;border:1px solid var(--hairline);border-radius:8px"><span><b class="mono ash" style="margin-right:14px">14:10</b>The Turn</span></div>
      <div class="row between" style="padding:14px 16px;border:1px solid var(--hairline);border-radius:8px"><span><b class="mono ash" style="margin-right:14px">19:30</b>The Standard</span></div>
    </div>
    <div class="row" style="margin-top:26px"><a class="link ash" href="#" data-share="copy" style="font-size:13px">Share link</a><a class="link ash" href="#" data-share="sms" style="font-size:13px">Text it</a><a class="link ash" href="#" data-share="email" style="font-size:13px">Email it</a><a class="link ash" href="#" data-share="report" style="font-size:13px;margin-left:auto">Report</a></div>
  </div>
  <aside class="stack-24">
    <div class="card"><div class="eyebrow" style="margin-bottom:14px">WHAT HE WISHED HE KNEW SOONER</div>
      <p class="quote" style="font-size:19px;margin-bottom:12px">"Coming home is work, not a doorway."</p>
      <p class="quote" style="font-size:19px;margin-bottom:12px">"Your kids don't need the story. They need the schedule."</p>
      <p class="quote" style="font-size:19px">"Repair beats explain. Every time."</p></div>
    <div class="card"><div class="eyebrow" style="margin-bottom:14px">WHAT HE TRAINS NOW</div>
      <div class="row" style="gap:16px"><div class="slot r-2x3" data-slot="IMG-P3-DET-02" style="flex:0 0 72px"></div>
      <div><b style="font-size:15px">Watch Ray's class: Coming Home Present</b><p class="small" style="margin-top:6px">5 sessions &middot; 1h 25m</p></div></div>
      <a class="btn btn-secondary btn-sm" href="class.html" style="margin-top:16px">Go to the class</a></div>
    <div class="card"><div class="eyebrow" style="margin-bottom:12px">WHERE HE STARTED</div>
      <p class="small" style="margin-bottom:14px">Ray's first Presence Baseline: <b class="mono bone">43</b></p>
      <a class="btn btn-yellow btn-sm" href="profile.html">Get yours</a></div>
  </aside>
</div></section>

<section class="band"><div class="container split" style="align-items:start">
  <div><h2 class="d-36">Your story is another man's map.</h2>
    <p style="color:var(--ash);margin-top:16px;max-width:46ch">Tell us what you went through and what you overcame. We film a handful of these every quarter. Every submission gets read.</p>
    <div class="grid-3" style="margin-top:32px;gap:14px">
      <div class="slot r-16x9" data-slot="IMG-P3-SUB-01"></div><div class="slot r-16x9" data-slot="IMG-P3-SUB-02"></div><div class="slot r-16x9" data-slot="IMG-P3-SUB-03"></div>
    </div><p class="fine" style="margin-top:10px">Filmed from submissions.</p></div>
  <form class="card" style="padding:32px" data-lead="story" data-done="Sent. Every submission gets read.">
    <div class="field"><label>The season that almost broke you</label><textarea name="season" required></textarea></div>
    <div class="field"><label>The turn</label><textarea name="turn" required></textarea></div>
    <div class="field"><label>The standard you hold now</label><textarea name="standard" required></textarea></div>
    <div class="field"><label>Contact email</label><input class="input" name="email" type="email" required placeholder="you@example.com"></div>
    <label style="display:flex;gap:10px;align-items:center;color:var(--bone);font-size:14px;margin-bottom:20px"><input type="checkbox" name="consent" required style="accent-color:var(--pine)"> You may contact me about filming.</label>
    <button class="btn btn-secondary">Send it</button>
  </form>
</div></section>
''')

# ================================================== classes.html (P4 catalog)
PAGES['classes.html'] = dict(title='The Courses', desc='Three courses, free to every man.', active='', mode='public', nochrome=True, body='''
<meta http-equiv="refresh" content="0;url=certificates.html">
<script>location.replace('certificates.html');</script>
<p class="center fine" style="padding:60px 0">The classes now live inside the three courses. <a class="link" href="certificates.html">Continue to The Courses &rarr;</a></p>
''')

PAGES['class.html'] = dict(title='The Fundamentals of Fathering', desc='The flagship class on presence, taught by Dr. Ken Canfield.', active='Classes', mode='public', body='''
<div class="billboard">
  <div class="slot r-21x9 flush filled" data-slot="IMG-P4-DET-01" style="max-height:64vh"><img src="assets/img/photos/community-02.jpg" alt="Fathers who took the course"></div>
  <div class="overlay container" style="left:50%;transform:translateX(-50%);max-width:var(--max)">
    <div class="eyebrow" style="margin-bottom:10px">THE FREE COURSE &middot; THE 7 SECRETS OF EFFECTIVE FATHERS</div>
    <h1 class="d-48">The Fundamentals of Fathering</h1>
    <p class="small" style="margin-top:10px">Dr. Ken Canfield. Founder, National Center for Fathering, since 1990. One standard.</p>
  </div>
</div>
<div class="nav" style="top:72px;z-index:50"><div class="container nav-inner" style="height:60px">
  <b style="font-size:15px">The Fundamentals of Fathering</b>
  <div class="nav-right"><a class="btn btn-yellow btn-sm" href="profile.html">Get your baseline</a></div>
</div></div>

<section class="tight"><div class="container" style="display:grid;grid-template-columns:1.45fr .85fr;gap:56px;align-items:start">
  <div>
    <h2 class="d-22" style="font-family:var(--font-display);font-size:22px;margin-bottom:18px">What you will train</h2>
    <div class="stack-8" style="margin-bottom:44px">
      <div class="actionrow"><span class="checkmark">&rarr;</span><div class="txt">Read your kids' inner weather.</div></div>
      <div class="actionrow"><span class="checkmark">&rarr;</span><div class="txt">Build a schedule they can trust.</div></div>
      <div class="actionrow"><span class="checkmark">&rarr;</span><div class="txt">Say what you stand for out loud.</div></div>
      <div class="actionrow"><span class="checkmark">&rarr;</span><div class="txt">Repair fast when you blow it.</div></div>
    </div>
    <h2 style="font-family:var(--font-display);font-size:22px;margin-bottom:8px">The five sessions</h2>
    <p class="fine" style="margin-bottom:14px">Five filmed sessions. Each ends in a checkpoint, and the course closes with the written Final Q&amp;A your facilitator reads.</p>
    <details open><summary><span><b class="mono ash" style="margin-right:14px">01</b>Why Presence Wins</span><span class="tag">17:16</span></summary>
      <div class="body"><div class="row" style="align-items:flex-start;gap:18px"><div class="slot r-16x9" data-slot="IMG-P4-DET-02" style="flex:0 0 180px"></div>
      <p style="font-size:14px">The research case for father presence, and your four Keystone scores read honestly. What your kids get when you show up, what it costs when you don't, and where you actually stand today.</p></div></div></details>
    <details><summary><span><b class="mono ash" style="margin-right:14px">02</b>A Schedule They Can Trust</span><span class="tag">18:51</span></summary><div class="body">Consistency mechanics: standing time, the calendar as covenant, and the distracted father. Attention your kids can feel.</div></details>
    <details><summary><span><b class="mono ash" style="margin-right:14px">03</b>Enter Their World</span><span class="tag">17:07</span></summary><div class="body">Awareness training: friends' names, inner weather, questions without fixing.</div></details>
    <details><summary><span><b class="mono ash" style="margin-right:14px">04</b>Repair Fast, Stand for Something</span><span class="tag">18:15</span></summary><div class="body">The 24-hour repair standard, values out loud, and discipline that builds instead of frightens.</div></details>
    <details><summary><span><b class="mono ash" style="margin-right:14px">05</b>Your Own Father, Your Ninety Days</span><span class="tag">19:12</span></summary><div class="body">What you inherited and what stops with you. Why no man holds a standard alone. Locking the plan and the retake.</div></details>
    <div class="row" style="align-items:flex-start;gap:20px;margin-top:44px">
      <div class="slot r-1x1" data-slot="IMG-P4-DET-03" style="flex:0 0 96px;border-radius:50%"></div>
      <div><h3 style="margin-bottom:8px">About Ken</h3>
      <p class="small" style="max-width:56ch">Dr. Ken Canfield founded the National Center for Fathering and built the research base behind the Keystone framework. Since 1990, thousands of fathers studied, one conclusion: presence is a trainable skill. He is a father of five and a grandfather, and he teaches like it.</p></div>
    </div>
  </div>
  <aside class="stack-24" style="position:sticky;top:160px">
    <div class="card"><div class="row" style="gap:16px"><span style="font-size:28px">▤</span>
      <div><b style="font-size:15px">The Fundamentals Workbook</b><p class="fine" style="margin-top:4px">28 pages</p></div></div>
      <a class="btn btn-secondary btn-sm" style="margin-top:16px;width:100%" href="checkout.html">Included with membership &rarr;</a></div>
    <div class="card"><div class="eyebrow" style="margin-bottom:14px">INCLUDED IN YOUR MEMBERSHIP</div>
      <div class="stack-8">
        <div class="check"><span class="checkmark">&check;</span><span class="small">Every film, class, and workbook, new releases monthly</span></div>
        <div class="check"><span class="checkmark">&check;</span><span class="small">Your baseline and plan</span></div>
        <div class="check"><span class="checkmark">&check;</span><span class="small">30-day money-back guarantee</span></div>
      </div></div>
    <div class="card brass-card"><p class="small" style="margin-bottom:12px">Need court-ready proof? Finish this course and your Certificate of Completion is issued at no cost.</p>
      <div class="row wrap" style="gap:14px;align-items:center">
        <a class="btn btn-yellow btn-sm" href="enroll.html?cert=fundamentals&amp;title=Fathering%20Fundamentals&amp;hours=10.0">Earn the certificate</a>
        <button class="link brass" id="seeCert" data-cert-course="The Fundamentals of Fathering" data-cert-hours="10.0" style="font-size:14px;background:none;border:none;cursor:pointer;padding:0;text-decoration:underline;text-underline-offset:3px">See the Certificate</button></div></div>
  </aside>
</div></section>

<section class="band tight"><div class="container">
  <h2 style="font-family:var(--font-display);font-size:24px;margin-bottom:20px">Keep training. The other two.</h2>
  <div class="rowscroll" data-repeat="2" data-prefix="IMG-P4-REL-" data-ratio="r-2x3" data-href="certificates.html#catalog"
    data-titles="Steady Under Pressure|Coming Home Present"
    data-subs="A man&rsquo;s temper, trained|Presence after time away"
    data-metas="5 sessions &middot; Certificate of Completion|5 sessions &middot; Certificate of Completion"></div>
</div></section>
<script src="assets/js/cert-preview.js"></script>
''')

# ================================================== player.html (P5)
PAGES['player.html'] = dict(title='Session 4 &middot; The Fundamentals of Fathering', desc='Session player.', active='Classes', mode='app', body='''
<section class="tight" style="padding-top:36px"><div class="container">
  <p class="tag" style="margin-bottom:14px">The Fundamentals of Fathering / Lesson 4</p>
  <div style="display:grid;grid-template-columns:1.55fr .75fr;gap:32px;align-items:start">
    <div>
      <div class="slot r-16x9 filled" data-slot="IMG-P5-PLY-01" id="stage"><img src="assets/img/photos/action-01.jpg" alt="Lesson still"></div>
      <div class="card" style="margin-top:14px;padding:14px 18px">
        <div class="row" style="gap:18px">
          <span class="mono small">06:12 / 18:15</span>
          <div class="progress-track" style="flex:1"><div class="progress-fill" style="width:36%"></div></div>
          <span class="chip" style="padding:4px 12px;font-size:12px" onclick="document.getElementById('audiobar').style.display='flex'">Audio</span>
        </div>
      </div>
      <div id="audiobar" class="card" style="display:none;margin-top:10px;padding:12px 16px;align-items:center;gap:14px">
        <div class="slot r-1x1" data-slot="IMG-P5-AUD-01" style="width:44px"></div>
        <b style="font-size:14px">Session 4 &middot; Repair Fast, Stand for Something</b>
        <span class="mono fine" style="margin-left:auto">Audio mode</span>
      </div>
      <div data-tabs style="margin-top:28px">
        <div class="tabs"><button class="active">Overview</button><button>Workbook</button><button>Notes</button></div>
        <div class="tabpanel active">
          <p class="small" style="max-width:64ch;margin-bottom:20px">Awareness is the skill of knowing your kids' inner weather before they announce it. This lesson trains three habits: learn the names, ask without fixing, and watch the transitions. Ten minutes now, a different dinner table by Friday.</p>
          <p class="quote" style="font-size:22px">"Consistency is love the kids can set a clock by."</p>
        </div>
        <div class="tabpanel">
          <div class="card" style="max-width:420px"><b style="font-size:15px">The Fundamentals Workbook</b><p class="fine" style="margin:6px 0 14px">Pages 12-15 pair with this session. Print them for the week.</p>
          <button class="btn btn-secondary btn-sm" data-print>Print the pages</button></div>
        </div>
        <div class="tabpanel">
          <div class="stack-16" style="max-width:560px">
            <div class="card" style="padding:16px"><span class="mono fine" style="display:inline-block;margin-bottom:8px">06:12</span><p class="small">Names of their three closest friends. I know one. One.</p></div>
            <div class="card" style="padding:16px"><span class="mono fine" style="display:inline-block;margin-bottom:8px">07:48</span><p class="small">Ask about the bus ride, not the grades.</p></div>
            <p class="fine">Notes save to your plan. Write like nobody's grading it.</p>
          </div>
        </div>
      </div>
      <div class="card" style="margin-top:30px;padding:28px">
        <div class="row between wrap">
          <div><div class="row" style="gap:10px;margin-bottom:8px"><span class="checkmark">&check;</span><b>Session 4 complete</b></div>
            <p class="small">Up next: Session 5, Your Own Father, Your Ninety Days</p></div>
          <div class="row"><button class="btn btn-primary btn-sm">Play now</button><button class="btn btn-secondary btn-sm" onclick="this.closest('.card').style.display='none'">Not now</button></div>
        </div>
        <hr class="hr" style="margin:20px 0">
        <p class="small">This week's action from your plan: <b class="bone">Eat breakfast with your kids twice.</b> Mark it done in My Plan. <a class="link ash" href="plan.html" style="font-size:13px">Go to My Plan</a></p>
      </div>
    </div>
    <aside class="card" style="padding:20px">
      <b style="font-size:15px">The Fundamentals of Fathering</b>
      <div class="row" style="margin:12px 0 20px"><div class="progress-track" style="flex:1"><div class="progress-fill pine" style="width:70%"></div></div><span class="mono fine">4 of 5</span></div>
      <div class="stack-8" style="font-size:14px">
        <div class="row between" style="padding:10px 12px;border-radius:6px;background:var(--coal-2)"><span><span class="checkmark" style="width:16px;height:16px;font-size:9px;flex:0 0 16px">&check;</span> 01 Why Presence Wins</span><span class="tag">17:16</span></div>
        <div class="row between" style="padding:10px 12px;border-radius:6px;background:var(--coal-2)"><span><span class="checkmark" style="width:16px;height:16px;font-size:9px;flex:0 0 16px">&check;</span> 02 A Schedule They Can Trust</span><span class="tag">18:51</span></div>
        <div class="row between" style="padding:10px 12px;border-radius:6px;background:var(--coal-2)"><span><span class="checkmark" style="width:16px;height:16px;font-size:9px;flex:0 0 16px">&check;</span> 03 Enter Their World</span><span class="tag">17:07</span></div>
        <div class="row between" style="padding:10px 12px;border-left:3px solid var(--ember);border-radius:6px;background:var(--coal-2)"><b>04 Repair Fast, Stand for Something</b><span class="tag">18:15</span></div>
        <div class="row between" style="padding:10px 12px"><span class="ash">05 Your Own Father, Your Ninety Days</span><span class="tag">19:12</span></div>
      </div>
    </aside>
  </div>
</div></section>
''')

# ================================================== plan.html (P6)
PAGES['plan.html'] = dict(title='Home', desc='Your baseline, your plan, your work.', active='Home', mode='app', auth=True, body='''
<section class="tight" style="padding-top:36px"><div class="container">
  <div class="pl-wrap">
    <div id="planRoot">
      <div id="planLoading" class="center" style="padding:80px 0">
        <div class="eyebrow" style="margin-bottom:12px">LOADING YOUR PLAN</div>
        <p class="ash">One moment.</p>
      </div>
    </div>
    <div id="homeFeed"></div>
  </div>
</div></section>
<script src="assets/js/keystone-data.js"></script>
<script src="assets/js/plan-engine.js"></script>
<script src="assets/js/plan-controller.js"></script>
<script src="assets/js/home.js"></script>
''')

PAGES['circles.html'] = dict(title='My Circle', desc='Living Hope Men. One film, one discussion, one standard.', active='Circles', mode='app', auth=True, body='''
<section class="tight" style="padding-top:44px"><div class="container">
  <div class="row between wrap" style="margin-bottom:24px">
    <div><h1 class="d-36">Living Hope Men, Tuesday 0600</h1>
      <div class="row" style="margin-top:12px"><span class="chip" style="cursor:default">14 men</span><span class="chip" style="cursor:default">Next: Tue Jul 14, 6:00 AM</span></div></div>
  </div>
  <div class="glance" style="margin-bottom:28px">
    <div class="glance-card"><div class="glance-lbl">YOUR CIRCLE</div><div class="glance-big">14</div><div class="glance-sub">men</div></div>
    <div class="glance-card"><div class="glance-lbl">THIS WEEK</div><div class="glance-big">9</div><div class="glance-sub">watched the film</div></div>
    <div class="glance-card"><div class="glance-lbl">NEXT MEETING</div><div class="glance-big glance-sm">Tue 0600</div><div class="glance-sub">Jul 14</div></div>
    <div class="glance-card glance-next"><div class="glance-lbl">CONSIDER NEXT</div><div class="glance-next-txt">Post this week's question, and nudge the five who haven't watched.</div></div>
  </div>
  <div data-tabs>
    <div class="tabs"><button class="active">This Week</button><button>Members</button><button>Leader Kit</button></div>

    <div class="tabpanel active"><div style="display:grid;grid-template-columns:1.5fr .8fr;gap:40px;align-items:start">
      <div>
        <div class="card" style="padding:28px;margin-bottom:26px">
          <div class="eyebrow" style="margin-bottom:14px">THIS WEEK IN CIRCLE</div>
          <div class="row" style="gap:18px;align-items:flex-start;margin-bottom:20px">
            <div class="slot r-16x9 filled" data-slot="IMG-P7-CIR-01" style="flex:0 0 200px"><img src="assets/img/photos/hero-07.jpg" alt="Film still"></div>
            <div><b style="font-size:15px">Watch before Tuesday: After the Sentence &middot; 22 min</b></div>
          </div>
          <p class="quote" style="font-size:20px;margin-bottom:18px">"Where did your father's absence still shape your hand?"</p>
          <div class="actionrow"><span class="checkmark">&rarr;</span><div class="txt">Tell one man in this Circle your week 3 action. Let him check you.</div></div>
        </div>
        <div class="card" style="padding:24px">
          <div class="row" style="margin-bottom:20px;gap:12px"><span class="avatarchip">M</span><input class="input" id="circlePostInput" placeholder="Say it straight"><button class="btn btn-primary btn-sm" id="circlePostBtn">Post</button></div>
          <div id="circleFeed"><p class="ash" style="padding:12px 0">Loading your circle&hellip;</p></div>
        </div>
      </div>
      <aside class="card" style="padding:20px">
        <div class="eyebrow" style="margin-bottom:16px">MEMBERS &middot; LAST 4 WEEKS</div>
        <table style="font-size:13px"><tbody>
          <tr><td style="padding:8px 4px">Marcus T.</td><td class="row" style="gap:6px;border:0;padding:8px 4px"><span class="dot on"></span><span class="dot on"></span><span class="dot on"></span><span class="dot on"></span></td></tr>
          <tr><td style="padding:8px 4px">Dave R.</td><td class="row" style="gap:6px;border:0;padding:8px 4px"><span class="dot on"></span><span class="dot on"></span><span class="dot"></span><span class="dot on"></span></td></tr>
          <tr><td style="padding:8px 4px">Tom K.</td><td class="row" style="gap:6px;border:0;padding:8px 4px"><span class="dot on"></span><span class="dot on"></span><span class="dot on"></span><span class="dot"></span></td></tr>
          <tr><td style="padding:8px 4px">Jesse P.</td><td class="row" style="gap:6px;border:0;padding:8px 4px"><span class="dot"></span><span class="dot"></span><span class="dot"></span><span class="dot on"></span></td></tr>
        </tbody></table>
      </aside>
    </div></div>

    <div class="tabpanel">
      <table><thead><tr><th>Name</th><th>Baseline taken</th><th>Last active</th><th>Weeks attended</th></tr></thead><tbody>
        <tr><td>Marcus T.</td><td><span class="checkmark" style="width:16px;height:16px;font-size:9px">&check;</span></td><td class="fine">Today</td><td class="mono fine">4 / 4</td></tr>
        <tr><td>Dave R.</td><td><span class="checkmark" style="width:16px;height:16px;font-size:9px">&check;</span></td><td class="fine">2h ago</td><td class="mono fine">3 / 4</td></tr>
        <tr><td>Tom K.</td><td><span class="checkmark" style="width:16px;height:16px;font-size:9px">&check;</span></td><td class="fine">5h ago</td><td class="mono fine">3 / 4</td></tr>
        <tr><td>Jesse P.</td><td class="fine">Not yet</td><td class="fine">1d ago</td><td class="mono fine">1 / 4</td></tr>
      </tbody></table>
    </div>

    <div class="tabpanel">
      <div class="grid-2" style="gap:24px">
        <div class="card"><b style="font-size:15px">Session guide</b><p class="fine" style="margin:6px 0 16px">After the Sentence &middot; 6 pages</p>
          <button class="btn btn-secondary btn-sm" data-print>Print the guide</button></div>
        <div class="card" style="grid-column:1/-1"><b style="font-size:15px">Plan the next 4 weeks</b>
          <div class="grid-4" style="margin-top:16px">
            <div class="slot r-16x9" data-slot="IMG-P7-KIT-01"></div>
            <div class="slot r-16x9" data-slot="IMG-P7-KIT-02"></div>
            <div class="slot r-16x9" data-slot="PICK A FILM"></div>
            <div class="slot r-16x9" data-slot="PICK A FILM"></div>
          </div></div>
      </div>
      <p class="fine" style="margin-top:20px">Leaders get the kit free. Ask us about training.</p>
    </div>
  </div>
</div></section>
<script src="assets/js/circles.js"></script>
''')

# ================================================== groups.html (P7 marketing + admin)
PAGES['groups.html'] = dict(title='For Groups', desc='Circles for churches, teams, and programs. Bring your men.', active='For Groups', mode='public', body='''
<header class="hero"><div class="container split">
  <div class="slot r-4x3" data-slot="IMG-P7-MKT-01"></div>
  <div>
    <div class="eyebrow" style="margin-bottom:16px">FOR GROUPS</div>
    <h1 class="d-48">Bring your men. We bring the plan.</h1>
    <p class="lead" style="margin:20px 0 30px">Films, discussion guides, baselines, and a weekly standard. Built for churches, teams, and programs. One link enrolls every man under your group. No rosters, no spreadsheets.</p>
    <a class="btn btn-primary" href="#contact">Talk to us</a>
  </div>
</div></header>

<section class="band tight"><div class="container">
  <div class="grid-2" style="max-width:880px;margin:0 auto">
    <div class="card" style="padding:32px"><div class="eyebrow" style="margin-bottom:12px">CIRCLE</div>
      <div class="bigscore" style="font-size:44px">$2,000<span class="ash" style="font-size:16px;font-family:var(--font-ui)"> / year</span></div>
      <p class="small" style="margin:8px 0 20px">Up to 25 seats</p>
      <div class="stack-8">
        <div class="check"><span class="checkmark">&check;</span><span class="small">Every class and film</span></div>
        <div class="check"><span class="checkmark">&check;</span><span class="small">Leader kits and guides</span></div>
        <div class="check"><span class="checkmark">&check;</span><span class="small">Admin analytics</span></div>
        <div class="check"><span class="checkmark">&check;</span><span class="small">Sponsored-seat option</span></div>
      </div></div>
    <div class="card" style="padding:32px"><div class="eyebrow" style="margin-bottom:12px">ORGANIZATION</div>
      <div class="bigscore" style="font-size:44px">Custom</div>
      <p class="small" style="margin:8px 0 20px">Custom seats, multi-Circle</p>
      <div class="stack-8">
        <div class="check"><span class="checkmark">&check;</span><span class="small">Everything in Circle</span></div>
        <div class="check"><span class="checkmark">&check;</span><span class="small">Rosters and CSV invites</span></div>
        <div class="check"><span class="checkmark">&check;</span><span class="small">Track assignment</span></div>
        <div class="check"><span class="checkmark">&check;</span><span class="small">Completion reporting</span></div>
      </div></div>
  </div>
  <p class="fine center" style="margin-top:18px">Pricing shown for design. Final pricing pends partner interviews.</p>
</div></section>

<section><div class="container">
  <div class="row between wrap" style="margin-bottom:24px">
    <h2 class="d-28">What an admin sees</h2>
    <span class="notice" style="padding:10px 16px">Admins see participation, never a man's answers or scores.</span>
  </div>
  <div class="grid-4" style="margin-bottom:28px">
    <div class="card stat"><div class="num">41<span class="ash" style="font-size:18px">/50</span></div><div class="lbl">Seats active</div></div>
    <div class="card stat"><div class="num">33</div><div class="lbl">Men on a plan</div></div>
    <div class="card stat"><div class="num">12</div><div class="lbl">Completions this quarter</div></div>
    <div class="card stat"><div class="num">4</div><div class="lbl">Circles running</div></div>
  </div>
  <div class="card pad-0">
    <div class="row between" style="padding:18px 20px;border-bottom:1px solid var(--hairline)">
      <div class="row" style="flex:1;max-width:480px"><input class="input" readonly id="joinLinkField" value="fathers.com/join/living-hope-4F7K"><button class="btn btn-secondary btn-sm" onclick="navigator.clipboard.writeText(document.getElementById('joinLinkField').value).then(function(){toast('Invite link copied.')})">Copy</button></div>
      <a class="btn btn-secondary btn-sm" href="mailto:Team@Fathers.com?subject=Roster%20import">Send us your roster</a>
    </div>
    <table><thead><tr><th>Name</th><th>Email</th><th>Baseline</th><th>Last active</th><th>Circle</th></tr></thead><tbody>
      <tr><td>Marcus T.</td><td class="fine">m.t@…</td><td><span class="checkmark" style="width:16px;height:16px;font-size:9px">&check;</span></td><td class="fine">Today</td><td class="fine">Tuesday 0600</td></tr>
      <tr><td>Dave R.</td><td class="fine">d.r@…</td><td><span class="checkmark" style="width:16px;height:16px;font-size:9px">&check;</span></td><td class="fine">2h</td><td class="fine">Tuesday 0600</td></tr>
      <tr><td>Luis A.</td><td class="fine">l.a@…</td><td class="fine">&mdash;</td><td class="fine">Invited</td><td class="fine">Thursday 1900</td></tr>
    </tbody></table>
  </div>
</div></section>

<section class="band" id="contact"><div class="container split" style="align-items:start">
  <div><h2 class="d-36">Start your Circles.</h2>
    <p style="color:var(--ash);margin-top:16px;max-width:44ch">Tell us about your men. We reply within three business days.</p>
    <div class="row wrap" style="margin-top:26px;gap:12px"><span class="pill pill-sponsored">Churches</span><span class="pill pill-sponsored">Synagogues</span><span class="pill pill-sponsored">Reentry programs</span><span class="pill pill-sponsored">Teams</span></div></div>
  <form class="card" style="padding:32px" data-lead="groups" data-done="Sent. We reply within three business days.">
    <div class="grid-2" style="gap:16px"><div class="field"><label>Name</label><input class="input" name="name" required></div>
      <div class="field"><label>Organization</label><input class="input" name="organization" required></div></div>
    <div class="grid-2" style="gap:16px"><div class="field"><label>Role</label><input class="input" name="role"></div>
      <div class="field"><label>Seats needed</label><input class="input" name="seats" placeholder="25"></div></div>
    <div class="field"><label>Email</label><input class="input" name="email" type="email" required></div>
    <div class="field"><label>Message</label><textarea name="message"></textarea></div>
    <button class="btn btn-primary">Send</button>
  </form>
</div></section>
''')

# ================================================== checkout.html (P8 screens 1-2)
PAGES['checkout.html'] = dict(title='Start your membership', desc='One membership. $120 a year. 30-day money-back guarantee.', active='', mode='public', body='''
<section class="tight" style="padding-top:56px"><div class="container" data-seq style="max-width:1080px">
  <div class="seqpanel">
    <div style="display:grid;grid-template-columns:1.2fr .9fr;gap:48px;align-items:start">
      <div>
        <h1 class="d-36" style="margin-bottom:14px">Start your membership.</h1>
        <p class="small" style="color:var(--ash);margin-bottom:24px;max-width:50ch">The membership is the library: every film, class, and workbook, new releases monthly. Your Profile, plan, retakes, the courses, and your Certificate of Completion stay free either way. The membership funds the work; it never gates it.</p>

        <div class="field"><label>Card number</label><input class="input" inputmode="numeric" placeholder="4242 4242 4242 4242"></div>
        <div class="grid-2" style="gap:16px">
          <div class="field"><label>Expiry</label><input class="input" placeholder="MM / YY"></div>
          <div class="field"><label>CVC</label><input class="input" inputmode="numeric" placeholder="123"></div>
        </div>
        <div class="grid-2" style="gap:16px">
          <div class="field"><label>Name on card</label><input class="input" placeholder="Marcus T."></div>
          <div class="field"><label>ZIP</label><input class="input" inputmode="numeric" placeholder="72712"></div>
        </div>
        <button class="btn btn-primary" id="paybtn" style="width:100%;margin-top:10px" data-next>Start my membership</button>
        <p class="fine" style="margin-top:14px">Payment processing wires to Stripe at deploy. No card is charged in this prototype.</p>
      </div>
      <aside class="card" style="padding:28px">
        <div class="row between" style="margin-bottom:4px"><b>Fathers.com Annual</b><b class="mono">$120.00</b></div>
        <p class="small" style="margin-bottom:14px">$10 a month, billed once a year</p>
        <div class="row between" style="margin-bottom:18px;padding:10px 12px;border:1px solid var(--hairline);border-radius:6px">
          <span class="small"><s class="ash">$120</s> <b class="bone">$79 founding member</b></span><span class="pill pill-new">Beta pricing</span></div>
        <div class="row" style="gap:10px;margin-bottom:18px"><span class="checkmark">&check;</span><span class="small">30-day money-back guarantee, no questions</span></div>
        <hr class="hr" style="margin-bottom:18px">
        <div class="stack-8">
          <div class="check"><span class="checkmark">&check;</span><span class="small">Every film, class, and workbook, new releases monthly</span></div>
          <div class="check"><span class="checkmark">&check;</span><span class="small">Your baseline and ninety-day plan</span></div>
          <div class="check"><span class="checkmark">&check;</span><span class="small">The Daily</span></div>
          <div class="check"><span class="checkmark">&check;</span><span class="small">Audio and downloads</span></div>
        </div>
        <p class="fine" style="margin-top:18px">By continuing you agree to the <a class="link ash" href="terms.html" style="font-size:12px">terms</a>. Pricing shown for design pending pricing interviews.</p>
      </aside>
    </div>
  </div>
  <div class="seqpanel">
    <div class="center" style="max-width:640px;margin:40px auto">
      <span class="checkmark" style="width:56px;height:56px;font-size:26px;margin:0 auto 22px;display:inline-flex">&check;</span>
      <h1 class="d-36" style="margin-bottom:10px">You're in.</h1>
      <p class="small" style="margin-bottom:36px">Receipt sent to m•••@•••.com.</p>
      <div class="grid-2" style="gap:20px;text-align:left">
        <a class="card hoverable" href="plan.html" style="text-decoration:none;color:inherit"><div class="eyebrow" style="margin-bottom:10px">NEXT</div><b>Pick up your plan. Week 1 is ready.</b></a>
        <a class="card hoverable" href="class.html" style="text-decoration:none;color:inherit"><div class="slot r-16x9" data-slot="IMG-P8-CNF-01" style="margin-bottom:12px"></div><b>Start the flagship class</b></a>
      </div>
    </div>
  </div>
</div></section>
''')

# ================================================== gift.html (P8 screens 3-4)
PAGES['gift.html'] = dict(title='Give a man the work', desc='Fund a year of full membership and materials for a man you believe in. The courses and his Certificate of Completion are free for every man; your gift funds the rest and tells him you are behind him.', active='', mode='public', body='''
<div class="billboard">
  <div class="slot r-21x9 flush" data-slot="IMG-P8-GFT-01" style="max-height:48vh"></div>
  <div class="overlay container" style="left:50%;transform:translateX(-50%);max-width:var(--max)">
    <h1 class="d-48">Back the work. He earns the proof.</h1>
    <p class="small" style="margin-top:10px;max-width:52ch">The courses and the Certificate of Completion are free for every man. Your gift funds a year of full membership and his printed materials, with your name on it. The completion is still earned, never given. He will know it came from you.</p>
  </div>
</div>
<section class="tight"><div class="container split" style="align-items:start">
  <div class="card" style="padding:32px">
    <div class="row between" style="margin-bottom:10px"><b>One sponsored seat</b><b class="mono">$120</b></div>
    <p class="fine" style="margin-bottom:22px">A year of full membership plus his printed workbooks and materials for all three courses: Fathering Fundamentals, Steady Under Pressure, Coming Home Present. His Keystone Profile, ninety-day plan, the courses, and his Certificate of Completion are free for every man, gift or not.</p>
    <div class="grid-2" style="gap:16px">
      <div class="field"><label>To</label><input class="input" id="g-to" placeholder="Dad"></div>
      <div class="field"><label>From</label><input class="input" id="g-from" placeholder="Marcus"></div>
    </div>
    <div class="field"><label>Message</label><textarea id="g-msg" maxlength="200" placeholder="You showed me. Now train it."></textarea>
      <p class="fine" style="margin-top:6px"><span id="g-count">200 left</span></p></div>
    <div class="field"><label>Delivery</label>
      <div class="chiprow"><button class="chip selected" data-deliver="now">Send now</button><button class="chip" data-deliver="date">Pick a date</button></div>
      <input class="input" id="g-date" type="date" value="2027-06-20" style="display:none;margin-top:12px;max-width:220px">
    </div>
    <div class="field"><label>Method</label>
      <div class="chiprow"><button class="chip selected" data-toggle="single">Email</button><button class="chip" data-toggle="single">Printable card</button></div></div>
    <form class="row" data-lead="gift-interest" data-done="You are on the list. We will email you the moment giving opens." style="gap:10px">
      <input class="input" name="email" type="email" required placeholder="Your email" style="flex:1">
      <button class="btn btn-primary">Reserve this gift</button>
    </form>
    <p class="fine" style="margin-top:8px">Gift checkout opens shortly. Reserve it now and we will email you first.</p>
    <p class="fine" style="margin-top:12px"><b class="bone">Completions are earned, never given.</b> You are backing the work, not buying the paper: identity confirmed, hours logged, a final at eighty percent. When he passes, the document is his because he earned it. That is why it means something.</p>
    <p class="fine" style="margin-top:8px">Giving to a man you have not met? <a class="link ash" href="sponsor.html">Sponsor a man &rarr;</a></p>
  </div>
  <div>
    <div class="eyebrow" style="margin-bottom:14px">HE SEES THIS</div>
    <div class="doc" style="padding:40px;max-width:520px;margin:0">
      <img src="assets/img/logomark-dark.png" alt="Fathers.com" style="height:36px;margin-bottom:24px">
      <p style="font-family:var(--font-mono);font-size:12px;letter-spacing:.2em;color:#6b6257;text-transform:uppercase;margin-bottom:14px">A sponsored seat</p>
      <h2 style="font-size:26px;color:#141210;margin-bottom:16px">For <span id="pv-to">Dad</span>, from <span id="pv-from">Marcus</span></h2>
      <p id="pv-msg" style="font-family:var(--font-display);font-size:19px;color:#3a352e;line-height:1.45;margin-bottom:24px">You showed me. Now train it.</p>
      <span style="display:inline-block;background:#E86A3C;color:#0A0A0A;padding:13px 24px;border-radius:6px;font-weight:600;font-size:14px">Claim it and take your baseline</span>
      <p style="font-size:11px;color:#6b6257;margin-top:18px">No card required to redeem.</p>
    </div>
  </div>
</div></section>
<section class="band tight"><div class="container center" style="max-width:620px">
  <div class="eyebrow" style="margin-bottom:16px">REDEMPTION PREVIEW</div>
  <h2 class="d-28" style="margin-bottom:12px">Marcus sponsored your seat, paid in full.</h2>
  <p class="quote" style="font-size:20px;margin-bottom:26px">"You showed me. Now train it."</p>
  <a class="btn btn-primary" href="profile.html">Claim it and take your baseline</a>
  <p class="fine" style="margin-top:14px">No card required to redeem.</p>
</div></section>
<script>
(function(){
  var t=document.getElementById('g-to'),f=document.getElementById('g-from'),m=document.getElementById('g-msg'),c=document.getElementById('g-count');
  function u(){document.getElementById('pv-to').textContent=t.value||'Dad';document.getElementById('pv-from').textContent=f.value||'Marcus';document.getElementById('pv-msg').textContent=m.value||'You showed me. Now train it.';c.textContent=(200-m.value.length)+' left';}
  [t,f,m].forEach(function(x){x.addEventListener('input',u)});u();
  document.querySelectorAll('[data-deliver]').forEach(function(b){b.addEventListener('click',function(){
    document.querySelectorAll('[data-deliver]').forEach(function(x){x.classList.remove('selected')});b.classList.add('selected');
    document.getElementById('g-date').style.display=b.dataset.deliver==='date'?'':'none';});});
})();
</script>
''')

# ================================================== sponsor.html (P8 screen 5)
PAGES['sponsor.html'] = dict(title='Sponsor a man', desc='$120 funds one man&rsquo;s seat and materials in a certified program. Tax-deductible. He earns the completion; you fund the work.', active='', mode='public', body='''
<header class="hero"><div class="container split">
  <div class="slot r-4x3" data-slot="IMG-P8-SPN-01"></div>
  <div>
    <h1 class="d-48">Sponsor a man.</h1>
    <p class="lead" style="margin:20px 0 8px">$120 funds one man&rsquo;s seat and printed materials in a certified program. The courses and the Certificate of Completion are free to him; your gift carries the cohort.</p>
    <p class="small" style="margin-bottom:28px">Your gift is tax-deductible. Fathers.com is a program of the National Center for Fathering, a 501(c)(3).</p>
    <div class="chiprow" style="margin-bottom:16px">
      <button class="chip selected" data-toggle="single">1 man &middot; $120</button>
      <button class="chip" data-toggle="single">3 men &middot; $360</button>
      <button class="chip" data-toggle="single">10 men &middot; $1,200</button>
      <button class="chip" data-toggle="single">Custom</button>
    </div>
    <label style="display:flex;gap:12px;align-items:center;color:var(--bone);font-size:14px;margin-bottom:18px"><input type="checkbox" class="toggle"> Make it monthly</label>
    <p class="fine" style="max-width:52ch;margin-bottom:12px">Sponsored seats are assigned through Certified Organizations. You will get one update when your seat is claimed. No personal details, no program names, ever.</p>
    <p class="fine" style="max-width:52ch;margin-bottom:12px">Churches and programs: sponsor ten and we set up your join link, one link that enrolls every man under your group.</p>
    <p class="fine" style="max-width:52ch;margin-bottom:26px">Giving to your own dad or a friend? <a class="link ash" href="gift.html">Give a man the work &rarr;</a></p>
    <form class="row" data-lead="sponsor-interest" data-done="Received. We will email you when sponsorship checkout opens." style="gap:10px;max-width:440px">
      <input class="input" name="email" type="email" required placeholder="Your email" style="flex:1">
      <button class="btn btn-primary">Sponsor</button>
    </form>
    <p class="fine" style="margin-top:8px;max-width:52ch">Sponsorship checkout opens shortly. Leave your email and we will set up your seats first.</p>
  </div>
</div></header>
''')

# ================================================== account.html (P9)
PAGES['account.html'] = dict(title='Account', desc='Settings, membership, notifications.', active='', mode='app', auth=True, body='''
<section class="tight" style="padding-top:44px"><div class="container" style="max-width:880px">
  <div class="row between" style="margin-bottom:30px;align-items:center">
    <h1 class="d-36" style="margin:0">Account</h1>
    <a class="btn btn-secondary btn-sm" href="#" data-signout>Sign out</a>
  </div>
  <div data-tabs>
    <div class="tabs"><button class="active">Profile</button><button>Membership</button><button>Notifications</button><button>Cancel path</button></div>

    <div class="tabpanel active">
      <div class="row" style="gap:20px;margin-bottom:28px"><div class="slot r-1x1" data-slot="IMG-P9-AVA-01" style="width:72px;border-radius:50%"></div><a class="link ash" href="mailto:Team@Fathers.com?subject=Change%20my%20account%20email" style="font-size:13px">Change</a></div>
      <div class="grid-2" style="gap:16px">
        <div class="field"><label>Name</label><input class="input" value="Marcus T."></div>
        <div class="field"><label>Email</label><input class="input" value="m.t@example.com"></div>
      </div>
      <div class="field"><label>Password</label><div class="row"><input class="input" type="password" value="••••••••••" readonly><button class="btn btn-secondary btn-sm" data-pwreset>Change</button></div></div>
      <div class="field"><label>Kids' age ranges</label>
        <div class="chiprow"><button class="chip selected" data-toggle>6-9</button><button class="chip selected" data-toggle>13-15</button><button class="chip" data-toggle>0-2</button><button class="chip" data-toggle>Teens</button></div>
        <p class="fine" style="margin-top:8px">Sets your plan. Never shown to anyone.</p></div>
      <div class="grid-2" style="gap:16px">
        <div class="field"><label>Faith lens</label><select class="input"><option>Not for me</option><option selected>Yes, Christian</option><option>Yes, Jewish</option></select></div>
        <div class="field"><label>Time zone</label><select class="input"><option selected>Central (CT)</option><option>Eastern (ET)</option><option>Mountain (MT)</option><option>Pacific (PT)</option></select></div>
      </div>
      <button class="btn btn-primary" data-prefs-save data-prefs-key="fc_account_profile">Save changes</button>
    </div>

    <div class="tabpanel">
      <div class="card" style="margin-bottom:20px"><div class="row between wrap">
        <div><b>Fathers.com Annual</b><p class="small" style="margin-top:6px">Renews March 4, 2027 &middot; $120</p></div>
        <a class="btn btn-secondary btn-sm" href="mailto:Team@Fathers.com?subject=Update%20my%20payment%20method">Update payment</a></div>
        <hr class="hr" style="margin:18px 0">
        <div class="row between"><span class="small">Visa ending 4242</span><a class="link ash" href="mailto:Team@Fathers.com?subject=Update%20my%20payment%20method" style="font-size:13px">Update</a></div></div>
      <div class="card" style="margin-bottom:20px"><div class="eyebrow" style="margin-bottom:14px">RECEIPTS</div>
        <table><tbody>
          <tr><td class="mono fine">Mar 4, 2026</td><td>Annual membership</td><td class="mono">$120.00</td><td><a class="link ash" href="#" data-print style="font-size:13px">PDF</a></td></tr>
          <tr><td class="mono fine">Jun 2, 2026</td><td>Sponsorship, one seat</td><td class="mono">$120.00</td><td><a class="link ash" href="#" data-print style="font-size:13px">PDF</a></td></tr>
        </tbody></table></div>
      <div class="grid-2" style="gap:16px;margin-bottom:24px">
        <a class="card hoverable" href="gift.html" style="text-decoration:none"><b style="font-size:15px">Give a gift</b><p class="fine" style="margin-top:6px">One year, from you.</p></a>
        <a class="card hoverable" href="sponsor.html" style="text-decoration:none"><b style="font-size:15px">Sponsor a man</b><p class="fine" style="margin-top:6px">A seat in a certified program, funded.</p></a>
      </div>
      <a class="link ash" href="#" style="font-size:14px" onclick="event.preventDefault();document.querySelectorAll('[data-tabs] .tabs button')[3].click()">Cancel membership</a>
      <p style="margin-top:26px"><a class="link ash" href="#" data-signout style="font-size:13px">Sign out</a></p>
    </div>

    <div class="tabpanel">
      <div class="stack-16" style="max-width:560px">
        <div class="row between"><span class="small">Weekly plan email, Monday 6:00 AM</span><input type="checkbox" class="toggle" checked onchange='if(!this.checked)toast("You will still get receipts and legal notices.")'></div>
        <div class="row between"><span class="small">Action reminders</span><input type="checkbox" class="toggle" checked></div>
        <div class="row between"><span class="small">New class drops</span><input type="checkbox" class="toggle" checked></div>
        <div class="row between"><span class="small">Circle activity</span><input type="checkbox" class="toggle" checked></div>
        <div class="row between"><span class="small">The Daily</span><input type="checkbox" class="toggle"></div>
      </div>
      <p class="fine" style="margin-top:22px">We send less than you expect. That's on purpose.</p>
    </div>

    <div class="tabpanel"><div data-seq style="max-width:560px">
      <div class="seqpanel">
        <h3 class="display d-28" style="margin-bottom:18px">Before you go: pause instead?</h3>
        <div class="card" style="margin-bottom:18px"><b>Pause 3 months</b><p class="small" style="margin:6px 0 16px">Keep your plan and progress. $0.</p>
          <a class="btn btn-primary btn-sm" href="mailto:Team@Fathers.com?subject=Pause%20my%20membership%20for%20three%20months">Request a pause</a></div>
        <a class="link ash" href="#" style="font-size:14px" data-next onclick="event.preventDefault()">Continue to cancel</a>
      </div>
      <div class="seqpanel">
        <h3 class="display d-28" style="margin-bottom:18px">What's the reason?</h3>
        <div class="chiprow" style="margin-bottom:18px">
          <button class="chip" data-toggle="single">Too expensive</button><button class="chip" data-toggle="single">Not using it</button><button class="chip" data-toggle="single">Finished what I came for</button><button class="chip" data-toggle="single">Something else</button></div>
        <div class="field"><textarea placeholder="Optional"></textarea></div>
        <button class="btn btn-secondary" data-next>Continue</button>
      </div>
      <div class="seqpanel">
        <h3 class="display d-28" style="margin-bottom:12px">You're set through March 4, 2027.</h3>
        <p class="small" style="margin-bottom:22px">Your baseline, plan, and notes stay saved. Come back any time.</p>
        <a class="btn btn-secondary" href="plan.html">Back to your plan</a>
      </div>
    </div></div>
  </div>
</div></section>
''')

# ================================================== certificates.html (P10 screens 1-3)
PAGES['certificates.html'] = dict(title='The Courses and the Certificate of Completion', desc='Three courses, free to every man. Finish the work and hold a Certificate of Completion: verified hours, a serial anyone can confirm, at no cost to you.', active='Certificates', mode='public', body='''
<!-- HERO: the certificate is the thesis -->
<header class="cert-hero"><div class="container">
  <div class="cert-hero-grid">
    <div class="cert-hero-copy">
      <div class="eyebrow brass" style="margin-bottom:18px">THE CERTIFICATE OF COMPLETION</div>
      <h1 class="cert-h1">A document that<br>means something.</h1>
      <p class="lead" style="margin:22px 0 34px">Not a participation ribbon. Earned proof that you did the work, free to the man who earns it. Signed by Dr. Ken Canfield and the Certified Facilitator who led your cohort, with verified hours and a serial anyone can confirm.</p>
      <div class="row wrap" style="gap:14px">
        <a class="btn btn-yellow" href="#catalog">See the three courses</a>
        <a class="btn btn-secondary" href="verify.html">Verify one</a>
      </div>
    </div>
    <div class="cert-hero-art">
      <div class="cert-doc-3d">
        <div class="cert-doc">
          <div class="cert-doc-brass"></div>
          <div class="cert-seal">
            <img src="assets/img/logomark-dark.png" alt="" class="lg-dark"><img src="assets/img/logomark-light.png" alt="" class="lg-light">
          </div>
          <div class="cert-doc-kicker">CERTIFICATE OF COMPLETION &middot; NATIONAL CENTER FOR FATHERING</div>
          <div class="cert-doc-name">Marcus T.</div>
          <div class="cert-doc-course">has completed Fathering Fundamentals</div>
          <div class="cert-doc-meta">10.0 verified instructional hours &middot; June 2, 2026</div>
          <div class="cert-doc-rule"></div>
          <div class="cert-doc-foot">
            <div><div class="cert-doc-serial">SERIAL FC-2026-004317</div><div class="cert-doc-serial">Identity confirmed at enrollment</div></div>
            <div class="cert-doc-qr">QR</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div></header>

<!-- WHAT IT PROVES: verification as the differentiator, four pillars -->
<section class="cert-proves"><div class="container">
  <div class="center" style="max-width:640px;margin:0 auto 56px">
    <h2 class="d-36">Anyone can print a certificate.<br>Ours can be checked.</h2>
    <p class="lead" style="margin:16px auto 0">Four things separate a Certificate of Completion from a PDF someone made in an afternoon.</p>
  </div>
  <div class="cert-pillars">
    <div class="cert-pillar">
      <div class="cert-pillar-n">01</div>
      <h3>Identity confirmed</h3>
      <p>Confirmed at enrollment: by government ID for independent enrollment, or in person by the Certified Facilitator who knows the man. The name on the certificate is the man who earned it.</p>
    </div>
    <div class="cert-pillar">
      <div class="cert-pillar-n">02</div>
      <h3>Hours logged, not claimed</h3>
      <p>Time on task is measured. No skip credit, no fast-forward. The hours on the document are hours he actually spent.</p>
    </div>
    <div class="cert-pillar">
      <div class="cert-pillar-n">03</div>
      <h3>Checkpoints passed</h3>
      <p>Attention checks through every lesson and a final assessment at eighty percent. He learned it, he did not just watch it.</p>
    </div>
    <div class="cert-pillar">
      <div class="cert-pillar-n">04</div>
      <h3>Publicly verifiable</h3>
      <p>Every certificate carries a unique serial with a public page. A court, an employer, or a program can confirm it instantly.</p>
    </div>
  </div>
</div></section>

<!-- HOW TO EARN ONE: make the process obvious -->
<section class="tight"><div class="container">
  <div class="center" style="max-width:640px;margin:0 auto 40px">
    <div class="eyebrow brass" style="margin-bottom:12px">HOW TO EARN ONE</div>
    <h2 class="d-36">Three steps to your certificate.</h2>
    <p class="small" style="margin-top:10px;color:var(--ash)">Every course is free. So is the certificate. Five sessions, fifteen to twenty minutes of film each plus the work, built for a working man&rsquo;s week. In a certified program the certificate is presented at completion, in front of the men you did the work with.</p>
  </div>
  <div class="grid-3">
    <div class="card" style="padding:24px"><div class="mono ash" style="margin-bottom:10px">STEP 1</div><b>Get claimed</b><p class="small" style="margin-top:8px">Your Certified Facilitator or organization claims your seat. Everything is free to you.</p></div>
    <div class="card" style="padding:24px"><div class="mono ash" style="margin-bottom:10px">STEP 2</div><b>Do the work</b><p class="small" style="margin-top:8px">Five sessions. Pass the checkpoint after each, then write your Final Q&amp;A answers. Time on task is measured.</p></div>
    <div class="card" style="padding:24px"><div class="mono ash" style="margin-bottom:10px">STEP 3</div><b>Receive your certificate</b><p class="small" style="margin-top:8px">Pass the final and receive a serialed Certificate of Completion a court or employer can confirm.</p></div>
  </div>
</div></section>

<!-- CATALOG: the certificates themselves -->
<section id="catalog" class="band"><div class="container">
  <div class="row between wrap" style="margin-bottom:40px;align-items:flex-end">
    <div><div class="eyebrow brass" style="margin-bottom:12px">THE THREE COURSES</div>
    <h2 class="d-36">Three courses. Chosen for the rooms where men are met.</h2></div>
    <p class="small" style="max-width:34ch">Open to every man, on either track. Presence, steadiness, and coming home: the three completions courts and programs actually ask for, built on the Keystone framework.</p>
  </div>
  <div class="cert-cards" id="tracks">
    <a class="cert-card" href="enroll.html?cert=fundamentals&amp;title=Fathering%20Fundamentals&amp;hours=10.0" data-cert="fundamentals" data-title="Fathering Fundamentals" data-hours="10.0" data-desc="The flagship curriculum, hardened into proof. The same lessons taught by fathers who have lived it, plus identity verification, logged time, checkpoints, and a final assessment.">
      <div class="cert-card-top"><span class="pill pill-court">Court-ready</span><span class="cert-card-hrs">10.0 hrs</span></div>
      <h3>Fathering Fundamentals</h3>
      <p>The flagship, built on The 7 Secrets of Effective Fathers. The free course, hardened into proof.</p>
      <div class="cert-card-foot"><span class="mono">Free</span><span class="cert-card-go">Start this course &rarr;</span></div>
    </a>
        <div class="cert-card" style="cursor:default" data-cert="reentry" data-title="Coming Home Present" data-hours="12.0" data-desc="Presence after time away, whatever kept you away. Rebuilding from day one, with confirmed identity, logged time, checkpoints, and a final assessment a court or program can trust.">
      <div class="cert-card-top"><span class="pill" style="opacity:.75">In development</span><span class="cert-card-hrs">12.0 hrs</span></div>
      <h3>Coming Home Present</h3>
      <p>Presence after time away, no matter what kept you away. Earned the hard way on purpose; the kind of proof other men respect. In development; waitlist members train first.</p>
      <div class="cert-card-foot"><span class="mono">Waitlist</span><a class="cert-card-go" href="#waitlist">Join the waitlist &rarr;</a></div>
    </div>
    <div class="cert-card" style="cursor:default" data-cert="anger" data-title="Steady Under Pressure" data-hours="8.0" data-desc="A man&rsquo;s temper, trained. The pause, the repair, and the steadiness the people around you can feel. Verified hours, identity checked, checkpoints, and a final assessment at eighty percent to pass.">
      <div class="cert-card-top"><span class="pill" style="opacity:.75">In development</span><span class="cert-card-hrs">8.0 hrs</span></div>
      <h3>Steady Under Pressure</h3>
      <p>A man&rsquo;s temper, trained. In development now; waitlist members shape the first cohort and train first.</p>
      <div class="cert-card-foot"><span class="mono">Waitlist</span><a class="cert-card-go" href="#waitlist">Join the waitlist &rarr;</a></div>
    </div>
      </div>

<section class="tight" id="waitlist"><div class="container" style="max-width:640px">
  <div class="eyebrow" style="margin-bottom:12px">THE NEXT COURSES</div>
  <h2 class="d-28" style="margin-bottom:8px">Two courses in development. Get in the first cohort.</h2>
  <p class="small" style="color:var(--ash);margin-bottom:18px">Steady Under Pressure and Coming Home Present are being built now. Waitlist members hear first, train first, and shape the curriculum.</p>
  <form class="row wrap" data-lead="track-waitlist" data-done="You are on the list. You will hear the moment enrollment opens.">
    <select class="input" name="track" required style="max-width:240px"><option value="" disabled selected>Which course?</option><option>Steady Under Pressure</option><option>Coming Home Present</option><option>Both</option></select>
    <input class="input" name="email" type="email" required placeholder="Email address" style="max-width:260px">
    <button class="btn btn-primary btn-sm">Join the waitlist</button>
  </form>
</div></section>
  <p class="fine" style="margin-top:20px">Every course and every Certificate of Completion is free to the man. Certified organizations and facilitators carry the standard; sponsorship funds seats and materials.</p>
</div></section>

<!-- PROOF IN CONTEXT: the certificate as a milestone, with real photography -->
<section class="cert-context"><div class="container">
  <div class="cert-context-grid">
    <div class="cert-context-photo">
      <img src="assets/img/photos/community-01.jpg" alt="Fathers gathered together">
    </div>
    <div class="cert-context-copy">
      <div class="eyebrow brass" style="margin-bottom:14px">WHY IT MATTERS</div>
      <h2 class="d-36" style="margin-bottom:20px">The document opens doors.<br>The work changes a family.</h2>
      <p class="lead" style="margin-bottom:16px">A judge sees a serial they can verify. A program sees hours they can trust. But the man who earned it sees something else: the proof that he showed up, learned, and became someone the people in his life can count on.</p>
      <p class="small">That is the difference between a certificate and a keepsake. This is both.</p>
    </div>
  </div>
</div></section>

<!-- REQUIREMENTS: the flagship, detailed -->
<section id="fundamentals"><div class="container">
  <div class="cert-req-grid">
    <div>
      <div class="eyebrow brass" style="margin-bottom:12px" id="certEyebrow">FLAGSHIP COURSE</div>
      <h2 class="d-36" style="margin-bottom:8px" id="certTitle">Fathering Fundamentals</h2>
      <p class="mono small" style="margin-bottom:24px" id="certHours">10.0 verified instructional hours</p>
      <p style="max-width:56ch;margin-bottom:32px;color:var(--ash)" id="certDesc">The flagship curriculum, hardened into proof. The same lessons taught by fathers who have lived it, plus confirmed identity, logged time, checkpoints, and a final assessment. Built for every man on either track, not just those with kids today.</p>
      <h3 style="font-family:var(--font-display);font-weight:500;font-size:20px;margin-bottom:18px">What earning it requires</h3>
      <div class="cert-reqs">
        <div class="cert-req"><span class="cert-req-mark">&check;</span><span>Identity confirmed at enrollment: government ID, or in-person attestation by a Certified Facilitator</span></div>
        <div class="cert-req"><span class="cert-req-mark">&check;</span><span>Attention checkpoints inside every lesson</span></div>
        <div class="cert-req"><span class="cert-req-mark">&check;</span><span>Time on task logged, with no credit for skipping</span></div>
        <div class="cert-req"><span class="cert-req-mark">&check;</span><span>A final assessment, eighty percent to pass</span></div>
        <div class="cert-req"><span class="cert-req-mark">&check;</span><span>Curriculum built on the Keystone framework, National Center for Fathering</span></div>
        <div class="cert-req"><span class="cert-req-mark">&check;</span><span>A unique serial with a public verification page</span></div>
      </div>
    </div>
    <aside class="cert-req-side">
      <div class="cert-req-card">
        <div class="cert-price-label"><span class="fine">THE COURSE AND THE CERTIFICATE</span></div>
        <div class="cert-req-price"><span class="mono">Free</span><span class="fine">to the man, always</span></div>
        <a class="btn btn-secondary" id="certExplore" href="enroll.html?cert=fundamentals&amp;title=Fathering%20Fundamentals&amp;hours=10.0" style="width:100%;margin-bottom:12px">Explore this course</a>
        <div class="cert-free-line">
          <span class="fine">Not sure yet?</span>
          <b>The Keystone Profile is free.</b>
          <p class="fine" style="margin-top:6px">Take your baseline first to see where to focus. No cost, no card.</p>
          <a class="btn btn-yellow" href="profile.html" style="width:100%;margin-top:12px">Take your free baseline</a>
        </div>
      </div>
      <div class="cert-req-note">
        <b>Running a program?</b>
        <p class="small" style="margin:6px 0 14px">Become a Certified Organization: credentialed facilitators, cohorts, and completion in your Efficacy Report. Free for your men, always.</p>
        <a class="link brass" href="organizations.html" style="font-size:14px">Get certified &rarr;</a>
      </div>
    </aside>
  </div>
</div></section>
<script>
(function(){
  var cards = document.querySelectorAll('.cert-card[data-cert]');
  var title = document.getElementById('certTitle');
  var hours = document.getElementById('certHours');
  var desc = document.getElementById('certDesc');
  var eyebrow = document.getElementById('certEyebrow');
  if(!title) return;
  cards.forEach(function(c){
    c.addEventListener('click', function(e){
      e.preventDefault();
      title.textContent = c.getAttribute('data-title');
      hours.textContent = c.getAttribute('data-hours') + ' verified instructional hours';
      desc.textContent = c.getAttribute('data-desc');
      eyebrow.textContent = c.getAttribute('data-cert')==='fundamentals' ? 'FLAGSHIP COURSE' : 'COURSE';
      var explore = document.getElementById('certExplore');
      if(explore){
        var slug = c.getAttribute('data-cert');
        var href = c.getAttribute('href');
        if(!href){ href = 'enroll.html?cert=' + encodeURIComponent(slug) + '&title=' + encodeURIComponent(c.getAttribute('data-title')||'') + '&hours=' + encodeURIComponent(c.getAttribute('data-hours')||''); }
        explore.setAttribute('href', href);
        explore.textContent = slug==='fundamentals' ? 'Explore this course' : 'Join the waitlist';
      }
      document.getElementById('fundamentals').scrollIntoView({behavior:'smooth'});
    });
  });
})();
</script>
''')

# ================================================== certificate.html (P10 screen 4)
PAGES['certificate.html'] = dict(title='Certificate FC-2026-004317', desc='Certificate of Completion, National Center for Fathering.', active='Certificates', mode='app', body='''
<section class="tight" style="padding-top:44px"><div class="container">
  <div class="row wrap" style="margin-bottom:28px;justify-content:center">
    <button class="btn btn-primary btn-sm" data-print>Print or save as PDF</button>
    <button class="btn btn-secondary btn-sm" data-share="email">Email to my officer or program</button>
    <button class="btn btn-secondary btn-sm" onclick="window.print()">Print</button>
  </div>
  <div class="doc">
    <div class="brassline"></div>
    <div class="row" style="justify-content:center;margin-bottom:26px"><img src="assets/img/logomark-dark.png" alt="Fathers.com" style="height:44px"></div>
    <div class="head">Certificate of Completion &middot; National Center for Fathering</div>
    <div class="name">Marcus T.</div>
    <div class="course">has completed the Fathering Fundamentals Certificate</div>
    <div class="hours">10.0 verified instructional hours &middot; Completed June 2, 2026</div>
    <div class="rule"></div>
    <div class="sealrow">
      <div>
        <div class="serial">SERIAL FC-2026-004317</div>
        <div class="serial" style="margin-top:6px">Identity verified at enrollment</div>
        <div class="serial" style="margin-top:6px">Issued by the National Center for Fathering</div>
        <div class="serial" style="margin-top:14px"><b>Verify at fathers.com/verify</b></div>
      </div>
      <div class="row" style="gap:18px;align-items:flex-end">
        <div class="qr">QR</div>
        <div class="slot r-1x1" data-slot="IMG-P10-CRT-01" style="width:84px;background:#EAE4D8;border-color:#B98A2F"></div>
      </div>
    </div>
  </div>
</div></section>
''')

# ================================================== verify.html (P10 screen 5, public, no chrome)

# ================================================== LEGAL PAGES (scaffolding, dated today)
# NOTE: The body text below is PLAIN-LANGUAGE DRAFT scaffolding for legal review.
# Replace with counsel-reviewed text before relying on these as binding policy.
LEGAL_INTRO = '''<div class="legal-note"><b>Draft for review.</b> This is placeholder scaffolding. Final language pends legal review to match Fathers.com's actual data and business practices.</div>'''

PAGES['terms.html'] = dict(title='Terms of Service', desc='The terms for using Fathers.com.', active='', mode='public', body='''
<section class="legal"><div class="container" style="max-width:760px">
  <div class="eyebrow brass" style="margin-bottom:14px">LEGAL</div>
  <h1 class="d-48" style="margin-bottom:8px">Terms of Service</h1>
  <p class="fine" style="margin-bottom:8px">Last updated July 06, 2026</p>
  ''' + LEGAL_INTRO + '''
  <div class="legal-body">
    <h2>1. Agreement to terms</h2>
    <p>By using Fathers.com, you agree to these terms. Fathers.com is a program of the National Center for Fathering, a 501(c)(3) nonprofit. If you do not agree, do not use the service.</p>
    <h2>2. Who can use Fathers.com</h2>
    <p>You must be at least 18 years old to create an account. The service is built for fathers, future fathers, and mentors. Content is intended for adults.</p>
    <h2>3. Your account</h2>
    <p>You are responsible for your account and for keeping your sign-in secure. Your assessment results and plan are yours. We describe how we handle your data in the Privacy Policy.</p>
    <h2>4. The Keystone Profile and your plan</h2>
    <p>The Keystone Father Profile is an educational assessment based on validated research from the National Center for Fathering. It is not a clinical, diagnostic, legal, or medical instrument, and results should not be used as a substitute for professional advice.</p>
    <h2>5. Certificates</h2>
    <p>Certificates of Completion require completion of the stated requirements, including identity confirmation and a passing assessment, and are issued at no cost to the participant. Certificates attest to completion of a Fathers.com course. Acceptance by any court, agency, or program is at that body's discretion; we do not guarantee acceptance.</p>
    <h2>6. Payments and subscriptions</h2>
    <p>The Keystone Profile is free. Certain courses, certificates, and subscriptions require payment. Pricing, billing terms, and refund policy will be stated at the point of purchase.</p>
    <h2>7. Acceptable use</h2>
    <p>Do not misuse the service, attempt to forge certificates, share your account, or use the service to harm others. We may suspend accounts that violate these terms.</p>
    <h2>8. Content and intellectual property</h2>
    <p>The courses, assessment, and materials on Fathers.com are owned by the National Center for Fathering or its licensors. You may use them for your own growth, not for redistribution.</p>
    <h2>9. Disclaimers and limitation of liability</h2>
    <p>The service is provided as is. To the fullest extent permitted by law, the National Center for Fathering is not liable for indirect or consequential damages arising from your use of the service.</p>
    <h2>10. Changes to these terms</h2>
    <p>We may update these terms. Material changes will be posted here with a new date. Continued use after changes means you accept them.</p>
    <h2>11. Contact</h2>
    <p>Questions about these terms: Team@Fathers.com, or PO Box 996, Tontitown, AR 72770.</p>
  </div>
</div></section>
''')

PAGES['privacy.html'] = dict(title='Privacy Policy', desc='How Fathers.com handles your information.', active='', mode='public', body='''
<section class="legal"><div class="container" style="max-width:760px">
  <div class="eyebrow brass" style="margin-bottom:14px">LEGAL</div>
  <h1 class="d-48" style="margin-bottom:8px">Privacy Policy</h1>
  <p class="fine" style="margin-bottom:8px">Last updated July 06, 2026</p>
  ''' + LEGAL_INTRO + '''
  <div class="legal-body">
    <h2>Our commitment</h2>
    <p>Fathers.com is a program of the National Center for Fathering. Your assessment answers and plan are personal. We treat them with care and we do not sell them.</p>
    <h2>What we collect</h2>
    <p>We collect: the email you use to sign in; your Keystone Profile answers and results; your plan progress; and basic technical data needed to run the service. We collect a government ID only when identity is confirmed that way at enrollment, and we delete it after issuance. When a Certified Facilitator confirms identity in person, no ID is collected by us at all.</p>
    <h2>How we use it</h2>
    <p>We use your information to give you your results, build and save your ninety-day plan, issue certificates you earn, and send you plan reminders and account emails. We do not use your assessment answers for advertising.</p>
    <h2>What we do not do</h2>
    <p>We do not sell your personal information. We do not share your assessment results with employers, courts, or programs unless you direct us to. We do not use your reflections about your family for any purpose beyond serving you.</p>
    <h2>Sharing</h2>
    <p>We share data only with service providers who help us run the platform (for example, hosting and email delivery), under agreements that require them to protect it. If you are enrolled through an employer or group, we describe separately what that organization can see.</p>
    <h2>Your choices</h2>
    <p>You can access your data, correct it, or ask us to delete your account and results. Contact Team@Fathers.com. You can unsubscribe from emails at any time.</p>
    <h2>Data retention</h2>
    <p>We keep your results and plan while your account is active. Identity documents for certificates are deleted after the certificate is issued. If you delete your account, we remove your personal data on a reasonable schedule.</p>
    <h2>Security</h2>
    <p>We protect your data with access controls and encryption in transit. See our Security page for more.</p>
    <h2>State privacy rights</h2>
    <p>Depending on where you live, you may have additional rights (for example, under California law) to access, delete, or restrict use of your information. Contact us to exercise them.</p>
    <h2>Changes</h2>
    <p>We may update this policy. Material changes will be posted here with a new date.</p>
    <h2>Contact</h2>
    <p>Privacy questions: Team@Fathers.com, or PO Box 996, Tontitown, AR 72770.</p>
  </div>
</div></section>
''')

PAGES['security.html'] = dict(title='Security', desc='How Fathers.com protects your information.', active='', mode='public', body='''
<section class="legal"><div class="container" style="max-width:760px">
  <div class="eyebrow brass" style="margin-bottom:14px">LEGAL</div>
  <h1 class="d-48" style="margin-bottom:8px">Security</h1>
  <p class="fine" style="margin-bottom:8px">Last updated July 06, 2026</p>
  ''' + LEGAL_INTRO + '''
  <div class="legal-body">
    <h2>How we protect your data</h2>
    <p>Fathers.com is built on modern, access-controlled infrastructure. Your data is protected by row-level security, so your results and plan are visible only to you and to staff who need access to run the service.</p>
    <h2>Encryption</h2>
    <p>Data is encrypted in transit. Sign-in uses secure, passwordless links rather than stored passwords.</p>
    <h2>Sensitive data</h2>
    <p>Identity documents submitted for certificates are used only to verify you and are deleted after the certificate is issued. We minimize the sensitive data we hold.</p>
    <h2>Access controls</h2>
    <p>Access to member data is limited by role. Administrative access is restricted and logged.</p>
    <h2>Reporting a concern</h2>
    <p>If you believe you have found a security issue, contact Team@Fathers.com. We take reports seriously and will respond.</p>
  </div>
</div></section>
''')

PAGES['verify.html'] = dict(title='Verify a credential', desc='Enter a serial. Confirm a Certificate of Completion, a Certified Facilitator, or a Certified Organization in the public registry.', active='', mode='public', nochrome=True, body='''
<div style="min-height:100vh;display:flex;flex-direction:column;align-items:center;padding:64px 20px">
  <a class="brand" href="index.html" style="margin-bottom:56px"><img class="lg-dark" src="assets/img/logomark-light.png" alt="Fathers.com logomark" style="height:34px"><img class="lg-light" src="assets/img/logomark-dark.png" alt="Fathers.com logomark" style="height:34px"><b style="font-family:var(--font-display);font-size:20px">Fathers.com</b></a>
  <div style="width:100%;max-width:520px">
    <h1 class="d-36" style="margin-bottom:8px">Verify a certificate</h1>
    <p class="small" style="margin-bottom:28px">Enter the serial printed on the document. Ten seconds, no login.</p>
    <form id="verifyForm" class="row" style="margin-bottom:28px">
      <input class="input mono" placeholder="FC-2026-004317" aria-label="Certificate serial">
      <button class="btn btn-primary">Verify</button>
    </form>
    <div id="v-ok" class="card" style="display:none;border-color:var(--pine-hi)">
      <div class="row" style="margin-bottom:18px"><span class="checkmark">&check;</span><b style="letter-spacing:.14em">VALID</b></div>
      <div class="stack-8">
        <div class="row between"><span class="fine">Recipient</span><b class="small" data-f="name"></b></div>
        <div class="row between"><span class="fine">Course</span><b class="small" data-f="course"></b></div>
        <div class="row between"><span class="fine">Hours</span><b class="small mono" data-f="hours"></b></div>
        <div class="row between"><span class="fine">Date</span><b class="small" data-f="date"></b></div>
        <div class="row between"><span class="fine">Serial</span><b class="small mono" data-f="serial"></b></div>
        <div class="row between"><span class="fine">Identity</span><b class="small">Verified at enrollment</b></div>
        <div class="row between"><span class="fine">Issuer</span><b class="small">National Center for Fathering</b></div>
      </div>
      <hr class="hr" style="margin:18px 0"><p class="small" style="margin-bottom:12px">This certificate was earned through logged hours, identity verification, and a proctored final. <a class="link" href="organizations.html">Issue these in your program &rarr;</a></p><a class="link ash" href="#" data-share="report" style="font-size:13px">Report a concern</a>
    </div>
    <div id="v-no" class="card" style="display:none;border-color:var(--error)">
      <b>NOT FOUND.</b><p class="small" style="margin-top:8px">Check the serial and try again.</p>
    </div>
    <p class="fine" style="margin-top:32px">Demo serials: FC-2026-004317 and FC-2026-001882. Production lookups read the certificates table. See supabase/schema.sql.</p>
  </div>
</div>
''')

# ================================================== veterans.html (P11)


# ================================================== employers.html (P12)
PAGES['employers.html'] = dict(title='For Employers', desc='Your parental benefits were built around mothers. Cover the fathers too.', active='', mode='public', body='''
<header class="hero"><div class="container split">
  <div>
    <div class="eyebrow" style="margin-bottom:16px">FOR EMPLOYERS</div>
    <h1 class="d-48">Paternity leave is two weeks. Fatherhood is forever.</h1>
    <p class="lead" style="margin:20px 0 30px">Your parental benefits were built around mothers. Give the fathers on your team a baseline, a plan, and training that fits the leave you already offer.</p>
    <a class="btn btn-primary" href="#partner">Become a design partner</a>
  </div>
  <div class="slot r-4x3" data-slot="IMG-P12-HER-01"></div>
</div></header>

<section class="band tight"><div class="container grid-3">
  <div class="card"><p style="font-size:17px;margin-bottom:12px">Most U.S. fathers take 10 or fewer days of leave.</p><p class="mono fine">[DOL-CITED RESEARCH]</p></div>
  <div class="card"><p style="font-size:17px;margin-bottom:12px">Paternal depression around a birth: roughly 1 in 10.</p><p class="mono fine">[JAMA META-ANALYSIS]</p></div>
  <div class="card"><p style="font-size:17px;margin-bottom:12px">Family benefits platforms are a proven employer category.</p><p class="mono fine">[MARKET COMPS ON REQUEST]</p></div>
</div></section>

<section class="tight"><div class="container">
  <h2 class="d-28" style="margin-bottom:24px">How it works</h2>
  <div class="steps3" style="margin-bottom:56px">
    <div class="s"><div class="n">01</div><p class="small" style="margin-top:8px">A father activates his seat before or during leave</p></div>
    <div class="s"><div class="n">02</div><p class="small" style="margin-top:8px">He takes the twenty-minute baseline and gets a leave-fitted plan</p></div>
    <div class="s"><div class="n">03</div><p class="small" style="margin-top:8px">You see activation and completion. Never his answers.</p></div>
  </div>
  <h2 class="d-28" style="margin-bottom:24px">What's in the seat</h2>
  <div class="grid-2" style="max-width:760px">
    <div class="stack-8">
      <div class="check"><span class="checkmark">&check;</span><span class="small">Every film, class, and workbook, new releases monthly</span></div>
      <div class="check"><span class="checkmark">&check;</span><span class="small">The new-father track</span></div>
      <div class="check"><span class="checkmark">&check;</span><span class="small">The Daily</span></div>
    </div>
    <div class="stack-8">
      <div class="check"><span class="checkmark">&check;</span><span class="small">Audio for the commute</span></div>
      <div class="check"><span class="checkmark">&check;</span><span class="small">Spouse gift seat</span></div>
      <div class="check"><span class="checkmark">&check;</span><span class="small"><b class="bone">Aggregate reporting only.</b></span></div>
    </div>
  </div>
</div></section>

<section class="band" id="partner"><div class="container split" style="align-items:start">
  <div><h2 class="d-36">We are selecting three employers to co-build this benefit.</h2>
    <p style="color:var(--ash);margin-top:16px;max-width:48ch">Partners get founding pricing, roadmap input, and a named case study, and they shape the reporting.</p></div>
  <form class="card" style="padding:32px" data-lead="employers" data-done="We read every application. Expect a reply within three business days.">
    <div class="grid-2" style="gap:16px"><div class="field"><label>Name</label><input class="input" name="name" required></div>
      <div class="field"><label>Company</label><input class="input" name="company" required></div></div>
    <div class="grid-2" style="gap:16px"><div class="field"><label>Role</label><input class="input" name="role"></div>
      <div class="field"><label>Employees on parental leave per year</label><select class="input" name="leave_volume"><option>Under 25</option><option>25-100</option><option>100-500</option><option>500 plus</option></select></div></div>
    <div class="field"><label>Email</label><input class="input" name="email" type="email" required></div>
    <div class="field"><label>Message</label><textarea name="message"></textarea></div>
    <button class="btn btn-primary">Apply to partner</button>
  </form>
</div></section>

<section class="tight"><div class="container" style="max-width:820px">
  <details><summary>How is this different from our EAP?</summary><div class="body">An EAP waits for a crisis call. This is training with a baseline, a plan, and completion you can see in aggregate. Fathers use it because it does not feel like an EAP.</div></details>
  <details><summary>What does HR see?</summary><div class="body">Activation and completion counts. Never a man's answers, scores, or notes. Aggregate reporting only.</div></details>
  <details><summary>How does it fit our leave policy?</summary><div class="body">The plan is fitted to the leave you already offer. Two weeks or twelve, the seat starts when he does and keeps running after he returns.</div></details>
  <details><summary>What does it cost?</summary><div class="body">Design partners set founding pricing with us. Per-seat, annual.</div></details>
</div></section>
''')


# ================================================== login.html (auth)
PAGES['login.html'] = dict(title='Sign in', desc='Sign in to Fathers.com to pick up your plan.', active='', mode='public', nochrome=True, body="""
<style>
.auth-page{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:48px 20px}
.auth-wrap{width:100%;max-width:420px;display:flex;flex-direction:column;align-items:center}
.auth-brand{display:inline-flex;align-items:center;gap:10px;text-decoration:none;margin-bottom:26px}
.auth-brand img{height:30px;width:auto}
.auth-brand span{font-family:var(--font-display);font-size:20px;font-weight:700;color:var(--bone)}
.auth-card{width:100%;background:var(--coal);border:1px solid var(--hairline);border-radius:16px;padding:36px 32px;box-shadow:var(--shadow)}
.auth-title{font-family:var(--font-display);font-size:26px;font-weight:600;color:var(--bone);margin-bottom:6px;letter-spacing:-.01em}
.auth-sub{font-size:14px;color:var(--ash);margin-bottom:26px;line-height:1.5}
.auth-field{margin-bottom:18px}
.auth-field label{display:block;font-size:13px;font-weight:600;color:var(--bone);margin-bottom:8px}
.auth-label-row{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}
.auth-label-row label{margin-bottom:0}
.auth-forgot{background:none;border:0;padding:0;cursor:pointer;font-family:var(--font-ui);font-size:13px;color:var(--brass);font-weight:500}
.auth-forgot:hover{text-decoration:underline;text-underline-offset:2px}
.auth-btn{width:100%;margin-top:6px}
.auth-msg{font-size:13px;margin-top:12px;min-height:16px;line-height:1.4}
.auth-or{display:flex;align-items:center;gap:14px;margin:22px 0}
.auth-or::before,.auth-or::after{content:"";flex:1;height:1px;background:var(--hairline)}
.auth-or span{font-size:12px;color:var(--ash)}
.auth-alt{margin-top:24px;font-size:14px;color:var(--ash);text-align:center}
.auth-alt a{color:var(--bone);font-weight:500;text-decoration:underline;text-underline-offset:3px}
.auth-legal{margin-top:34px;display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:center}
.auth-legal a{font-size:12px;color:var(--ash);text-decoration:none}
.auth-legal a:hover{color:var(--bone)}
.auth-legal span{font-size:12px;color:var(--hairline-strong)}
.auth-copy{margin-top:14px;font-size:11px;color:var(--ash);text-align:center;line-height:1.5;max-width:320px}
@media(max-width:480px){.auth-card{padding:28px 22px}}
</style>
<div class="auth-page"><div class="auth-wrap">
  <a class="auth-brand" href="index.html">
    <img class="lg-dark" src="assets/img/logomark-light.png" alt="Fathers.com">
    <img class="lg-light" src="assets/img/logomark-dark.png" alt="Fathers.com">
    <span>Fathers.com</span>
  </a>
  <div class="auth-card">
    <h1 class="auth-title" id="authTitle">Sign in</h1>
    <p class="auth-sub" id="authSub">Welcome back. Pick up your plan where you left off.</p>
    <form id="authForm" novalidate>
      <div class="auth-field" id="authNameField" style="display:none">
        <label for="authName">Your name</label>
        <input id="authName" class="input" type="text" autocomplete="name" placeholder="First name is fine">
      </div>
      <div class="auth-field">
        <label for="authEmail">Email</label>
        <input id="authEmail" class="input" type="email" autocomplete="username" placeholder="you@example.com" required>
      </div>
      <div class="auth-field">
        <div class="auth-label-row"><label for="authPass">Password</label><button type="button" class="auth-forgot" id="authForgot">Forgot?</button></div>
        <input id="authPass" class="input" type="password" autocomplete="current-password" placeholder="Your password">
      </div>
      <button class="btn btn-primary auth-btn" id="authSignin" type="submit">Sign in</button>
      <p class="auth-msg" id="authMsg" role="status" aria-live="polite"></p>
    </form>
  </div>
  <p class="auth-alt"><span id="authAltTxt">New here? </span><a href="#" id="authAltLink">Create an account</a></p>
  <div class="auth-legal">
    <a href="terms.html">Terms</a><span aria-hidden="true">&middot;</span>
    <a href="privacy.html">Privacy</a><span aria-hidden="true">&middot;</span>
    <a href="security.html">Security</a>
  </div>
  <p class="auth-copy">&copy; 2026 Fathers.com. A program of the National Center for Fathering.</p>
</div></div>
""")

# ================================================== enroll.html (claim-gated enrollment)
PAGES['enroll.html'] = dict(title='Enroll', desc='Enroll free. Finish the work and receive your Certificate of Completion.', active='Certificates', mode='app', body='''
<style>
.cpn-ok{color:var(--pine-hi)!important}
.cpn-err{color:var(--error)!important}
.enroll-code{display:flex;gap:10px;align-items:stretch}
.enroll-code .input{flex:1}
</style>
<section class="tight" style="padding-top:56px"><div class="container" style="max-width:1040px">
  <div id="enrollPanel">
    <a class="link ash" href="certificates.html" style="font-size:13px;display:inline-block;margin-bottom:20px">&larr; All certificates</a>
    <div style="display:grid;grid-template-columns:1.2fr .9fr;gap:48px;align-items:start" class="enroll-grid">
      <div>
        <div class="eyebrow brass" style="margin-bottom:14px">THE CERTIFICATE OF COMPLETION</div>
        <h1 class="d-36" style="margin-bottom:14px">Enroll in <span id="certTitle">this course</span></h1>
        <p class="lead" style="margin-bottom:30px">Court-ready proof that you did the work, at no cost to you. Identity confirmed, hours logged, checkpoints passed, and a serial anyone can confirm.</p>
        <div class="eyebrow" style="margin-bottom:16px">WHAT EARNING IT REQUIRES</div>
        <div class="stack-16">
          <div class="check"><span class="checkmark">&check;</span><span class="small">Confirm your identity once at enrollment: a government ID, checked then deleted, or in-person attestation by your Certified Facilitator.</span></div>
          <div class="check"><span class="checkmark">&check;</span><span class="small">Complete the instructional hours. Time on task is measured, not claimed.</span></div>
          <div class="check"><span class="checkmark">&check;</span><span class="small">Pass the checkpoints and a final assessment at eighty percent.</span></div>
          <div class="check"><span class="checkmark">&check;</span><span class="small">Receive a unique serial with a public verification page.</span></div>
        </div>
        <p class="fine" style="margin-top:24px">Seats come through people, not codes. A Certified Facilitator or Certified Organization claims your seat; your completion then counts in your cohort&rsquo;s report, and everything stays free to you.</p>
      </div>
      <aside class="card" style="padding:28px">
        <div class="row between" style="margin-bottom:4px"><b id="certTitleSum">This course</b><b class="mono" id="priceLine">Free</b></div>
        <p class="small" style="margin-bottom:20px"><span id="certHours">10.0</span> verified instructional hours &middot; no cost to you</p>

        <div class="card" style="padding:16px 18px;margin-bottom:16px;background:var(--coal-2);border:1px solid var(--hairline)">
          <div class="eyebrow" style="margin-bottom:8px">YOUR SEAT</div>
          <p class="small" id="claimStatus" style="margin:0">Your seat is claimed by your program&rsquo;s Certified Facilitator or Certified Organization. Signed in and claimed, this button enrolls you at no cost.</p>
        </div>
        <div class="row between" style="margin-bottom:20px"><b>Total</b><b class="mono" id="totalLine">Free</b></div>

        <button class="btn btn-primary" id="enrollBtn" style="width:100%">Enroll</button>
        <p class="fine" id="enrollNote" style="margin-top:14px">Not in a program yet? <a class="link ash" href="find-a-program.html">Find a certified program</a> or ask your organization to <a class="link ash" href="organizations.html">get certified</a>.</p>
      </aside>
    </div>
  </div>

  <div id="waitlistPanel" hidden>
    <a class="link ash" href="certificates.html" style="font-size:13px;display:inline-block;margin-bottom:20px">&larr; All certificates</a>
    <div style="max-width:640px">
      <div class="eyebrow brass" style="margin-bottom:14px">IN DEVELOPMENT</div>
      <h1 class="d-36" style="margin-bottom:14px"><span id="wlTitle">This certificate</span></h1>
      <p style="color:var(--ash);margin-bottom:22px">This track is being built now. Waitlist members hear first, train first, and shape the curriculum. Earned the hard way on purpose; that is the kind of proof men respect.</p>
      <form class="row wrap" data-lead="track-waitlist" data-done="You are on the list. You will hear the moment enrollment opens." style="gap:12px">
        <input type="hidden" name="track" id="wlTrack" value="">
        <input class="input" name="email" type="email" required placeholder="Email address" style="max-width:280px">
        <button class="btn btn-primary">Join the waitlist</button>
      </form>
      <p class="fine" style="margin-top:18px">Today, the flagship course, The 7 Secrets of Effective Fathers, is free to every member. <a class="link" href="class.html">Start free &rarr;</a></p>
    </div>
  </div>
  <div id="successPanel" style="display:none">
    <div class="center" style="max-width:620px;margin:40px auto">
      <span class="checkmark" style="width:56px;height:56px;font-size:26px;margin:0 auto 22px;display:inline-flex">&check;</span>
      <h1 class="d-36" style="margin-bottom:10px">You are enrolled.</h1>
      <p class="small" style="margin-bottom:36px">Your seat in <b class="bone" id="successTitle">this certificate</b> is saved. Your first step is to verify your identity, then begin the hours. Nothing expires, so start whenever you are ready.</p>
      <div class="row wrap" style="gap:14px;justify-content:center">
        <a class="btn btn-primary" id="beginBtn" href="class.html">Begin your certificate</a>
        <a class="btn btn-secondary" href="plan.html">Back to My Plan</a>
      </div>
    </div>
  </div>
</div></section>
<script src="assets/js/enroll.js"></script>
''')

# --- shared top for every veteran page: styles + always-present crisis strip ---
VET_TOP = '''<link rel="stylesheet" href="assets/css/veterans.css">
'''

# ================================================== veterans.html (front door)


# ================================================== veterans-hub.html


# ================================================== veterans-resources.html
PAGES['veterans-resources.html'] = dict(title='The Homefront', desc='Support, on your terms.', active='', mode='public', nochrome=True, body='''
<meta http-equiv="refresh" content="0;url=veterans-hub.html#support">
<script>location.replace('veterans-hub.html#support');</script>
<p class="center fine" style="padding:60px 0">This now lives inside your hub. <a class="link" href="veterans-hub.html#support">Continue &rarr;</a></p>
''')

PAGES['veterans-checkin.html'] = dict(title='A private check-in', desc='A private, two-minute check-in that points you to the right support. Not a diagnosis.', active='For Veterans', mode='app', body=VET_TOP + '''
<section class="tight"><div class="container" style="max-width:760px">
  <div class="eyebrow brass" style="margin-bottom:12px">PRIVATE, ABOUT TWO MINUTES</div>
  <h1 class="d-36" style="margin-bottom:18px">A check-in, just for you</h1>
  <div id="vetCheckin"></div>
</div></section>
<script src="assets/js/veterans-core.js"></script>
<script src="assets/js/veterans-checkin.js"></script>
''')

# ================================================== voice.html


# ================================================== veterans-module.html
PAGES['veterans-module.html'] = dict(title='A skill for returning fathers', desc='A short, plain lesson for returning fathers.', active='For Veterans', mode='app', auth=True, body=VET_TOP + '''
<section class="tight"><div class="container" style="max-width:760px">
  <a class="link ash" href="veterans-hub.html" style="font-size:13px;display:inline-block;margin-bottom:20px">&larr; Your hub</a>
  <div id="vetModule"><p class="ash">Loading&hellip;</p></div>
  <div style="margin-top:36px"><a class="link" id="vetModuleNext" href="veterans-hub.html">Next &rarr;</a></div>
</div></section>
<script src="assets/js/veterans-core.js"></script>
<script src="assets/js/veterans-modules.js"></script>
''')

# ================================================== veterans.html (front door, rebuilt)


# ================================================== veterans-hub.html (editorial hub, rebuilt)


PAGES['veterans-hub.html'] = dict(title='The Homefront', desc='Train for the mission at home: the field guide, the Legacy Archive, your ground, your record. Built for fathers who served.', active='For Veterans', mode='app', auth=True, body=VET_TOP + '''
<section class="vet-hero" style="min-height:420px">
  <img class="vet-hero-img" src="assets/img/photos/community-01.jpg" alt="">
  <div class="vet-hero-inner">
    <div class="vet-hero-eyebrow">Fathers.com &middot; For those who served</div>
    <h1>The mission continues.</h1>
    <p class="vet-hero-lead" id="vetGreet">You carried the load out there. This is where you train for the one that matters most, and put it on the record. You are early; the men here first set the standard.</p>
  </div>
</section>

<section class="vet-ed vet-ed-noline" style="padding-top:8px">
  <div class="vet-ed-head">
    <div id="orgSupport" hidden class="card" style="padding:18px 22px">
      <div class="vet-ed-eyebrow" style="margin-bottom:6px">YOUR PROGRAM'S SUPPORT</div>
      <p class="small" id="orgSupportTxt" style="margin:0"></p>
    </div>
  </div>
</section>

<section class="vet-ed vet-ed-noline" id="startHere">
  <div class="vet-ed-head">
    <div class="vet-ed-eyebrow">First fifteen minutes</div>
    <h2>Three moves. Then everything below makes sense.</h2>
  </div>
  <div class="grid-3" style="margin-top:22px">
    <div class="card" style="padding:24px 26px" data-vetstep="checkin">
      <div class="row between" style="margin-bottom:10px"><span class="pill">STEP 1</span><span class="fine mono" data-state>&nbsp;</span></div>
      <h3 style="margin-bottom:6px">Take the check-in</h3>
      <p class="small" style="color:var(--ash);margin-bottom:14px">Two minutes, private, no wrong answers. It sets your starting point so the plan fits the week you are actually having.</p>
      <a class="btn btn-secondary btn-sm" href="veterans-checkin.html">Start the check-in</a>
    </div>
    <div class="card" style="padding:24px 26px" data-vetstep="film">
      <div class="row between" style="margin-bottom:10px"><span class="pill">STEP 2</span><span class="fine mono" data-state>&nbsp;</span></div>
      <h3 style="margin-bottom:6px">Watch your first film</h3>
      <p class="small" style="color:var(--ash);margin-bottom:14px">Short and plain, from fathers who walked back through the same door. Pick any one below; each is about six minutes.</p>
      <a class="btn btn-secondary btn-sm" href="#fieldguide">Pick a film</a>
    </div>
    <div class="card" style="padding:24px 26px" data-vetstep="voice">
      <div class="row between" style="margin-bottom:10px"><span class="pill">STEP 3</span><span class="fine mono" data-state>&nbsp;</span></div>
      <h3 style="margin-bottom:6px">Record sixty seconds</h3>
      <p class="small" style="color:var(--ash);margin-bottom:14px">Here is why: it plays on the nights you cannot be there, and it stays theirs no matter what. One take is enough. Prompts are ready if the words are not.</p>
      <a class="btn btn-secondary btn-sm" href="voice.html">Record it</a>
    </div>
  </div>
</section>

<section class="vet-ed vet-ed-noline" id="fieldguide">
  <div class="vet-ed-head">
    <div class="vet-ed-eyebrow">The field guide</div>
    <h2>Skills for the homefront</h2>
    <p>Short, plain films and reads on what gets hard when you walk back through the door. Built from what other fathers who served said they needed most.</p>
  </div>
  <div class="vet-stories">
    <a class="vet-story" href="veterans-module.html?m=reconnecting"><img src="assets/img/photos/hero-01.jpg" alt=""><div class="vet-story-body"><div class="vet-story-min">Film &middot; 6 min</div><h3>When your kid feels like a stranger</h3><p>Rebuilding closeness after time away</p></div></a>
    <a class="vet-story" href="veterans-module.html?m=temper"><img src="assets/img/photos/hero-02.jpg" alt=""><div class="vet-story-body"><div class="vet-story-min">Film &middot; 6 min</div><h3>Staying steady, and the way back</h3><p>Anger, the pause, and the repair</p></div></a>
    <a class="vet-story" href="veterans-module.html?m=emotion"><img src="assets/img/photos/hero-03.jpg" alt=""><div class="vet-story-body"><div class="vet-story-min">Film &middot; 5 min</div><h3>Saying what you feel</h3><p>Breaking through the numbness</p></div></a>
    <a class="vet-story" href="veterans-module.html?m=command"><img src="assets/img/photos/hero-04.jpg" alt=""><div class="vet-story-body"><div class="vet-story-min">Read &middot; 5 min</div><h3>From command to connection</h3><p>Leading a family is a different job</p></div></a>
    <a class="vet-story" href="veterans-module.html?m=coparenting"><img src="assets/img/photos/hero-05.jpg" alt=""><div class="vet-story-body"><div class="vet-story-min">Read &middot; 5 min</div><h3>Fathering across two homes</h3><p>Presence when you are not the only house</p></div></a>
    <a class="vet-story" href="veterans-module.html?m=nurturing"><img src="assets/img/photos/hero-06.jpg" alt=""><div class="vet-story-body"><div class="vet-story-min">Read &middot; 4 min</div><h3>Small acts, every day</h3><p>Nurturing is a set of habits</p></div></a>
  </div>
</section>

<section class="vet-ed">
  <div class="vet-split">
    <div>
      <div class="vet-ed-eyebrow">The Legacy Archive</div>
      <h2>Your voice, in their day. Forever theirs.</h2>
      <p>Record a story or a message your kids can replay when they miss you. Private to you, secured, and yours alone. It is the most personal tool here, and it has its own home.</p>
      <a class="btn btn-yellow" href="voice.html">Open Voice</a>
    </div>
    <img class="vet-split-img" src="assets/img/photos/hero-07.jpg" alt="">
  </div>
</section>

<section class="vet-ed">
  <div class="vet-ed-head">
    <div class="vet-ed-eyebrow">Your ground</div>
    <h2>Know it. Check it. Move it.</h2>
    <p>Two private tools that meet you where you are and point you forward. Yours alone, never shared.</p>
  </div>
  <div class="grid-2" style="gap:24px">
    <div class="card" style="padding:28px">
      <b class="bone" style="font-family:var(--font-display);font-size:20px">Your baseline</b>
      <p class="small" style="margin:10px 0 18px">The Keystone Profile shows your real strengths and the one place growth pays off most, then builds a plan around it.</p>
      <a class="btn btn-secondary" href="profile.html">Take your baseline</a>
    </div>
    <div class="card" style="padding:28px">
      <b class="bone" style="font-family:var(--font-display);font-size:20px">A private check-in</b>
      <p class="small" style="margin:10px 0 18px">Two quiet minutes, just for you. It is not a diagnosis. It points you to the right kind of support only if you want it.</p>
      <a class="btn btn-secondary" href="veterans-checkin.html">Take the check-in</a>
    </div>
  </div>
</section>

<section class="vet-ed" id="credential">
  <div class="vet-ed-head">
    <div class="vet-ed-eyebrow">Earned, never given</div>
    <h2>The certificate is coming. It will cost you effort.</h2>
    <p>Coming Home Present: identity checked, hours logged, a final passed. Peers respect it because it cannot be bought. Waitlist members train first. Today, the flagship course, The 7 Secrets of Effective Fathers, is already yours, free.</p>
  </div>
  <div class="row wrap" style="gap:12px;margin-top:6px">
    <a class="btn btn-secondary btn-sm" href="enroll.html?cert=reentry&title=Coming%20Home%20Present&hours=12.0">Join the waitlist</a>
    <a class="btn btn-yellow btn-sm" href="class.html">Start the free course</a>
  </div>
</section>

<section class="vet-ed vet-ed-noline" id="support">
  <div class="vet-ed-head">
    <div class="vet-ed-eyebrow">Support, on your terms</div>
    <p>You know the resources; nobody here needs a lecture. When you want one: <b id="vetMatchName">your Vet Center</b> for a conversation, Military OneSource for the practical, and around the clock, <a class="link" href="tel:988">988, press 1</a>.</p>
  </div>
</section>

<section style="max-width:1200px;margin:0 auto;padding:24px">
  <div class="vet-brother">
    <img class="vet-brother-img" src="assets/img/photos/community-02.jpg" alt="">
    <div class="vet-brother-inner">
      <h2>You are not the first one home.</h2>
      <p>Thousands of men have walked back through that door and had to learn how to be a father all over again. You are joining their ranks, not starting from nothing.</p>
    </div>
  </div>
</section>

<section class="vet-quote">
  <blockquote>&ldquo;I could lead a platoon, but I could not get my own kid to talk to me. Learning that was its own kind of training.&rdquo;</blockquote>
  <div class="vet-quote-by"><img src="assets/img/photos/testimonial-01.jpg" alt=""><span>A father, three deployments</span></div>
</section>


<script src="assets/js/veterans-core.js"></script>
<script src="assets/js/veterans-hub.js"></script>
''')

# ================================================== veterans.html (public: pitch + free films)
PAGES['veterans.html'] = dict(title='Present at Home', desc='For fathers who served: train for the mission at home and leave them your voice, in your own words, theirs forever. Free forever.', active='For Veterans', mode='public', body=VET_TOP + '''
<section class="vet-hero">
  <img class="vet-hero-img" src="assets/img/photos/billboard-home.jpg" alt="">
  <div class="vet-hero-inner">
    <div class="vet-hero-eyebrow">Fathers.com &middot; For those who served</div>
    <h1>The next mission is the one at home.</h1>
    <p class="vet-hero-lead">You did the hard thing over there. Coming all the way home to your kids is its own kind of hard, and nobody hands you orders for it. Train for it in fifteen minutes a week, and leave them something no program ever gave a man: your voice, in your own words, theirs forever. Free forever for those who served.</p>
    <div class="vet-hero-actions">
      <a class="btn btn-yellow" href="#watch">Watch, free</a>
      <a class="btn btn-onimg" href="login.html?next=veterans-start.html">Join free</a>
    </div>
  </div>
</section>

<section class="vet-ed vet-ed-noline">
  <div class="vet-ed-head">
    <div class="vet-ed-eyebrow">The shift</div>
    <h2>They built programs for broken men. You were never broken.</h2>
    <p>You were between missions. So this is not treatment and it is not a support group. It is training, a record, and proof: the way you would run any mission that matters.</p>
  </div>
</section>

<section class="vet-ed" id="archive">
  <div class="vet-ed-head">
    <div class="vet-ed-eyebrow">The Legacy Archive</div>
    <h2>Leave them your voice.</h2>
    <p>Guided prompts, recorded in your own words: why you serve, the hard days, the things you want them to know at sixteen. Plenty of good programs help a man read a book to his kids across the miles. A book ends. Your voice, your words, your story: that stays, theirs forever, no matter what.</p>
  </div>
  <div class="row wrap" style="gap:12px;margin-top:6px">
    <a class="btn btn-yellow" href="login.html?next=voice.html">Join free, record tonight</a>
    <a class="link" href="voice.html" style="align-self:center">Already in? Open the Archive &rarr;</a>
  </div>
</section>

<section class="vet-ed vet-ed-noline" id="watch">
  <div class="vet-ed-head">
    <div class="vet-ed-eyebrow">Watch, free</div>
    <h2>Three films. Start with the one that hits home.</h2>
    <p>Short, honest lessons from fathers who came home and had to learn this. Watch all three, no account needed.</p>
  </div>
  <div class="vet-films">
    <button class="vet-film" data-key="reconnecting" data-title="When your kid feels like a stranger">
      <div class="vet-film-thumb"><img src="assets/img/photos/hero-01.jpg" alt=""><span class="vet-film-play"></span><span class="vet-film-dur">Watch</span></div>
      <div class="vet-film-meta"><h3>When your kid feels like a stranger</h3><p>Rebuilding closeness after time away</p></div>
    </button>
    <button class="vet-film" data-key="emotion" data-title="Saying what you feel">
      <div class="vet-film-thumb"><img src="assets/img/photos/hero-03.jpg" alt=""><span class="vet-film-play"></span><span class="vet-film-dur">Watch</span></div>
      <div class="vet-film-meta"><h3>Saying what you feel</h3><p>Breaking through the numbness, out loud</p></div>
    </button>
    <button class="vet-film" data-key="temper" data-title="Staying steady, and the way back">
      <div class="vet-film-thumb"><img src="assets/img/photos/hero-02.jpg" alt=""><span class="vet-film-play"></span><span class="vet-film-dur">Watch</span></div>
      <div class="vet-film-meta"><h3>Staying steady, and the way back</h3><p>Anger, the pause, and the repair</p></div>
    </button>
  </div>
  <div class="vet-lock">
    <div>
      <div class="eyebrow brass" style="margin-bottom:8px">The rest of the field guide</div>
      <b class="bone" style="font-size:18px">All three films are right here, free.</b>
      <p class="small" style="margin-top:6px">Join free for the written field notes, your plan, and the Legacy Archive, and to get each new film the day it lands. No cost, ever, for those who served.</p>
    </div>
    <a class="btn btn-yellow" href="login.html?next=veterans-start.html">Join free</a>
  </div>
  <p class="fine" style="margin-top:18px">Already a member? <a class="link" href="veterans-hub.html">Go to your hub &rarr;</a></p>
</section>

<section class="vet-ed">
  <div class="vet-ed-head">
    <div class="vet-ed-eyebrow">What you get when you join</div>
    <h2>Everything a man needs to come all the way home.</h2>
    <p>Fifteen minutes gets you moving: a two-minute private check-in, your first film, and sixty seconds recorded in your own voice for your kids. Then all of this, free forever.</p>
  </div>
  <div class="grid-4" style="gap:28px">
    <div><b class="bone" style="font-size:16px">The full field guide</b><p class="small" style="margin-top:8px">Every film and read on what gets hard when you walk back through the door.</p></div>
    <div><b class="bone" style="font-size:16px">The Legacy Archive</b><p class="small" style="margin-top:8px">Guided prompts, recorded in your voice, titled and kept for your kids: bedtime, milestones, the hard days, your story.</p></div>
    <div><b class="bone" style="font-size:16px">Support matched to you</b><p class="small" style="margin-top:8px">The one free service built for your situation, with the number and what to expect.</p></div>
    <div><b class="bone" style="font-size:16px">A private check-in</b><p class="small" style="margin-top:8px">Two minutes, just for you. Not a diagnosis. It points you to help if you want it.</p></div>
  </div>
</section>

<section class="vet-ed" id="routine">
  <div class="vet-ed-head">
    <div class="vet-ed-eyebrow">Still serving? The Return Routine</div>
    <h2>If the next call-up is already on the calendar.</h2>
    <p>Guard, reserve, or active: some fathers come home again and again. If that is you, this routine is yours. The temptation is to keep a little distance so the next goodbye hurts less. Your kids cannot afford that math. Get close anyway. This is the routine that makes it possible.</p>
  </div>
  <div class="grid-3" style="margin-top:26px">
    <div class="card" style="padding:26px"><div class="eyebrow" style="margin-bottom:10px">BEFORE YOU GO</div><p class="small" style="color:var(--ash)">Record three things in the Legacy Archive: why you go, what you promise, and one to play when they miss you. Brief each kid in one sentence they can repeat. Ten minutes, total. <a class="link" href="voice.html">Record now &rarr;</a></p></div>
    <div class="card" style="padding:26px"><div class="eyebrow" style="margin-bottom:10px">WHILE YOU ARE AWAY</div><p class="small" style="color:var(--ash)">One voice note beats zero phone calls. Away-night prompts are ready for when you have two minutes and no words. She is holding the line at home; ask her for one thing you can own from a distance. <a class="link" href="voice.html">The prompts &rarr;</a></p></div>
    <div class="card" style="padding:26px"><div class="eyebrow" style="margin-bottom:10px">THE FIRST 72 HOURS HOME</div><p class="small" style="color:var(--ash)">Re-entry is a handoff, not a takeover. Take the private check-in, protect one evening at the table, and give each kid ten minutes alone with you. Expect the little ones to test you on day two. That is attachment, not disrespect. <a class="link" href="veterans-checkin.html">The check-in &rarr;</a></p></div>
  </div>
  <p class="fine" style="margin-top:18px">Between returns, your plan keeps one small move in front of you. And when the next call comes, the archive means your voice stays home even when you cannot.</p>
</section>

<section class="vet-ed">
  <div class="vet-ed-head">
    <div class="vet-ed-eyebrow">The certificate track &middot; in development</div>
    <h2>Coming Home Present. Earned, never given.</h2>
    <p>A verified certificate built for men who serve and return: identity checked, hours logged, a final passed. Earned the hard way on purpose. That is the kind of proof men respect, because it cannot be bought. It is in development now; waitlist members train first. Today, the flagship course, The 7 Secrets of Effective Fathers, is already free to every member.</p>
  </div>
  <p style="margin-top:4px"><a class="btn btn-secondary btn-sm" href="certificates.html#waitlist">Join the waitlist</a></p>
</section>

<section class="vet-ed">
  <div class="vet-ed-head">
    <div class="vet-ed-eyebrow">For units and programs</div>
    <h2>Bringing your whole unit?</h2>
    <p>One join link enrolls every man under your cohort: the Keystone Profile, the free flagship course, the ninety-day plan, and the Legacy Voice Archive, with the veteran certificate track as it releases. Leadership sees cohort movement, never a man&rsquo;s private answers. <a class="link" href="organizations.html">For Organizations &rarr;</a></p>
  </div>
</section>

<section class="vet-ed vet-ed-noline">
  <div class="vet-ed-head" style="text-align:center">
    <div class="vet-ed-eyebrow">Know a man who served?</div>
    <p>Send him this page. It costs him nothing, and his kids keep his voice forever.</p>
    <p style="margin-top:14px"><button class="btn btn-secondary btn-sm" id="vetShare">Copy the link</button> <span class="fine" id="vetShareMsg" style="margin-left:10px"></span></p>
  </div>
</section>
<script>
(function(){
  var b=document.getElementById('vetShare'); if(!b) return;
  b.addEventListener('click', function(){
    var url=location.origin+'/veterans.html';
    (navigator.clipboard?navigator.clipboard.writeText(url):Promise.reject()).then(function(){
      document.getElementById('vetShareMsg').textContent='Copied. Send it to him.';
    }, function(){ document.getElementById('vetShareMsg').textContent=url; });
  });
})();
</script>

<p class="fine" style="text-align:center;color:var(--ash);padding:26px 0 8px">Around the clock, if you ever want it: <a class="link" href="tel:988">988, press 1</a>.</p>

<div id="vetVideoModal" class="vet-vmodal" hidden>
  <div class="vet-vmodal-backdrop" data-vclose></div>
  <div class="vet-vmodal-inner">
    <button class="vet-vmodal-x" data-vclose aria-label="Close">&times;</button>
    <div id="vetVideoStage"></div>
    <div class="vet-vmodal-cap"><b id="vetVideoTitle"></b><a class="btn btn-yellow btn-sm" href="login.html?next=veterans-start.html">Join free for the rest</a></div>
  </div>
</div>
<script src="assets/js/veterans-core.js"></script>
<script src="assets/js/veterans-video.js"></script>
''')

# ================================================== veterans-start.html (identify, after joining)
PAGES['veterans-start.html'] = dict(title='Set up your hub', desc='Tell us where you are so we can point you to what fits.', active='For Veterans', mode='app', body=VET_TOP + '''
<section class="vet-ed vet-ed-noline" style="padding-top:56px;max-width:720px">
  <div class="vet-ed-head">
    <div class="vet-ed-eyebrow">Welcome in</div>
    <h2>Let us set up your hub.</h2>
    <p>Two quick taps so we can point you to what fits. This is saved to your account.</p>
  </div>
  <div id="vetStartLoading" class="ash" style="padding:20px 0">One moment&hellip;</div>
  <div id="vetOnboard" hidden>
    <div class="vet-step" data-step="1">
      <button class="vet-opt" data-ctx="active"><span>I am serving now, active, Guard, or Reserve</span></button>
      <button class="vet-opt" data-ctx="veteran"><span>I am a veteran</span></button>
      <button class="vet-opt" data-ctx="family"><span>I am a military family member</span></button>
    </div>
    <div class="vet-step" data-step="2" hidden>
      <p class="lead" style="margin-bottom:26px">A little context. Optional, and it sharpens the match. Skip any time.</p>
      <div class="vet-field" data-combat>
        <div class="eyebrow">DID YOU SERVE IN A COMBAT ZONE?</div>
        <div class="row" style="gap:10px"><button class="chip" data-val="yes" aria-pressed="false">Yes</button><button class="chip" data-val="no" aria-pressed="false">No</button></div>
      </div>
      <div class="vet-field" data-sep-block hidden>
        <div class="eyebrow">HOW LONG SINCE YOU SEPARATED?</div>
        <div class="row" style="gap:10px" data-sep><button class="chip" data-val="recent" aria-pressed="false">Within the last year</button><button class="chip" data-val="past" aria-pressed="false">More than a year ago</button></div>
      </div>
      <div class="vet-field" data-kids>
        <div class="eyebrow">YOUR KIDS&rsquo; AGES (TAP ANY)</div>
        <div class="row wrap" style="gap:10px"><button class="chip" data-band="0-5" aria-pressed="false">0 to 5</button><button class="chip" data-band="6-12" aria-pressed="false">6 to 12</button><button class="chip" data-band="13-18" aria-pressed="false">13 to 18</button><button class="chip" data-band="grown" aria-pressed="false">Grown</button></div>
      </div>
      <div class="row wrap" style="gap:14px;margin-top:12px">
        <button class="btn btn-primary" id="vetContinue">Go to my hub</button>
        <a class="link ash" href="#" data-skip style="align-self:center">Skip</a>
      </div>
    </div>
  </div>
</section>
<script src="assets/js/veterans-core.js"></script>
<script src="assets/js/veterans-start.js"></script>
''')

PAGES['voice.html'] = dict(title='The Legacy Archive', desc='Leave them your voice. Sixty seconds tonight outlives almost everything else you will make this week.', active='For Veterans', mode='app', body=VET_TOP + '''
<section class="vx">
  <div class="vx-col">
    <h1>Leave them your voice.</h1>
    <p class="vx-sub">Sixty seconds tonight outlives almost everything else you will make this week.</p>

    <div class="vx-card" id="voiceApp">
      <div class="vx-lbl">TONIGHT&rsquo;S PROMPT</div>
      <div class="vx-prompt" id="vPrompt">Say good night the way you always do.</div>
      <p class="vx-links"><button class="link brass" id="vSwap" type="button">Different prompt</button></p>

      <div class="row" style="align-items:center;gap:14px">
        <button class="vrec" id="vBtn" type="button" aria-label="Record"><span class="vrec-dot"></span><span class="vrec-lbl" id="vBtnLbl">Record</span></button>
        <div class="voice-timer" id="voiceTimer">&nbsp;</div>
      </div>
      <p class="fine vx-hint">Tap to record. Tap Stop when you are done.</p>
      <p class="fine" id="voiceMsg" style="margin-top:6px;min-height:16px"></p>

      <div id="vDone" hidden style="margin-top:14px;border-top:1px solid #2f3336;padding-top:16px">
        <p class="small" id="vDoneTxt" style="margin-bottom:12px;color:#e7e9ea;font-size:15px"></p>
        <audio id="voicePreview" controls style="width:100%;margin:0 0 14px;display:block"></audio>
        <div class="row" style="gap:10px;flex-wrap:wrap">
          <button class="btn btn-secondary btn-sm" id="vUndo" type="button">Undo</button>
          <button class="btn btn-yellow btn-sm" id="vAgain" type="button">Record another</button>
          <button class="btn btn-primary btn-sm" id="vShareNow" type="button" hidden>Share it</button>
          <a class="btn btn-primary btn-sm" id="vKeep" href="login.html?next=voice.html" hidden>Join free to keep it</a>
        </div>
      </div>

      <p class="fine" style="margin-top:16px">Encrypted &middot; private to you &middot; never shared &middot; delete anytime</p>
      <p class="fine" id="vGuest" hidden>Record first. Keeping it takes a free sign-in after, and we will hold this one for you.</p>
    </div>

    <details id="vAllWrap" style="margin-top:18px">
      <summary>The full prompt library</summary>
      <div class="voice-prompts" style="margin-top:14px">
        <div id="promptPicker"></div>
        <p class="fine" id="promptCurrent" hidden style="margin-top:10px"></p>
      </div>
    </details>

    <div id="voiceList"></div>
    <p class="fine" style="margin-top:26px;text-align:center">Kids replay these on their schedule. That is the whole point.</p>
  </div>
</section>
<script src="assets/js/veterans-core.js"></script>
<script src="assets/js/voice.js"></script>
''')

PAGES['share.html'] = dict(title='A message for you', desc='A private voice message, recorded on Fathers.com.', active='For Veterans', mode='public', body=VET_TOP + '''
<section class="vx" style="min-height:60vh">
  <div class="vx-col" style="text-align:center">
    <div class="vx-lbl" style="margin-top:10px">THE LEGACY ARCHIVE</div>
    <h1 id="shTitle" style="margin-bottom:6px">Loading&hellip;</h1>
    <p class="vx-sub">A father recorded this for you.</p>
    <div class="vx-card">
      <audio id="shAudio" controls hidden style="width:100%"></audio>
      <p class="fine" id="shMsg" style="margin-top:12px;min-height:16px"></p>
    </div>
    <p class="fine" style="margin-top:22px">Private link. No account needed, and nothing is collected from you.</p>
    <div style="margin-top:36px;border-top:1px solid #2f3336;padding-top:28px">
      <p class="vx-sub" style="margin-bottom:16px">This came from the Legacy Archive on Fathers.com, where a father banks his voice for his kids, forever. Free, forever, for those who served.</p>
      <a class="btn btn-yellow" id="shStart" href="veterans.html?src=share">Start your own archive</a>
    </div>
  </div>
</section>
<script src="assets/js/share.js"></script>
''')


PAGES['course.html'] = dict(title='Your Certificate', desc='Watch the lessons, pass each Checkpoint, answer the final Q&A, and submit for approval.', active='Certificates', mode='app', auth=True, body='''
<section class="cw-wrap" id="cw-root">
  <div class="cw-head">
    <a class="link ash" href="certificates.html" style="display:inline-block;margin-bottom:16px">&larr; All certificates</a>
    <div class="eyebrow brass">THE CERTIFICATE OF COMPLETION</div>
    <h1 class="d-36" id="cw-title" style="margin-top:8px">Your certificate</h1>
  </div>
  <div id="cw-note"></div>
  <div id="cw-stage"><p class="ash">Loading\u2026</p></div>
</section>
<script src="assets/js/coursework.js"></script>
''')

# ================================================== find-a-program.html
PAGES['find-a-program.html'] = dict(title='Find a Program', desc='The program directory publishes with the first rated cohort on the Keystone Standard.', active='', mode='public', body='''
<section class="tight" style="padding-top:72px"><div class="container" style="max-width:760px;text-align:center">
  <div class="eyebrow" style="margin-bottom:16px">FIND A PROGRAM</div>
  <h1 class="d-36" style="margin-bottom:14px">The directory opens with the first rated cohort.</h1>
  <p style="color:var(--ash);max-width:56ch;margin:0 auto 34px">Programs are being measured on the Keystone Standard now: the same instrument, the same norms, the same report. When the first cohort's ratings publish, this page becomes the place a father finds a program that provably works. Until then, we will not point you at a list we cannot stand behind.</p>
  <div class="grid-2" style="gap:22px;text-align:left">
    <div class="card" style="padding:28px">
      <div class="eyebrow" style="margin-bottom:12px">FOR A FATHER, TODAY</div>
      <p class="small" style="color:var(--ash);margin-bottom:18px">You do not need a directory to start. The Profile is free, takes about twenty minutes, and your ninety-day plan builds itself from your answers.</p>
      <a class="btn btn-primary" href="profile.html">Start your Profile</a>
    </div>
    <div class="card" style="padding:28px">
      <div class="eyebrow" style="margin-bottom:12px">RUN A PROGRAM?</div>
      <p class="small" style="color:var(--ash);margin-bottom:18px">Get on the Standard now and in line for the first rated cohort. Twenty minutes, your funder&rsquo;s report, live.</p>
      <a class="btn btn-secondary" href="organizations.html#walkthrough">Get on the Standard</a>
    </div>
  </div>
  <p class="fine" style="margin-top:28px">Want to know the moment the directory opens?</p>
  <form class="row" style="justify-content:center;margin-top:12px" data-lead="directory-waitlist" data-done="You are on the list. You will hear when the first ratings publish.">
    <input class="input" name="email" type="email" required placeholder="Email address" style="max-width:280px">
    <button class="btn btn-secondary btn-sm">Notify me</button>
  </form>
</div></section>
''')

PAGES['organizations.html'] = dict(title='Become a Certified Organization', desc='NCF certifies organizations and facilitators against a published standard: credentialed facilitators, baseline and exit measurement, honest reporting. Free for your men, always.', active='For Organizations', mode='public', body='''
<section class="tight" style="padding:52px 0 44px"><div class="container split" style="align-items:center;gap:56px">
  <div>
    <div class="eyebrow" style="margin-bottom:14px">CERTIFICATION FOR ORGANIZATIONS</div>
    <h1 class="d-48" style="margin-bottom:16px">Become a Certified Organization.</h1>
    <p style="color:var(--ash);max-width:52ch;margin-bottom:24px">Every program says it works. Certification is how you prove it: credentialed facilitators, baseline and exit measurement on one instrument, and the report your funder already asks for. Your men pay nothing. Your organization carries the standard.</p>
    <div class="row wrap" style="gap:12px;margin-bottom:22px">
      <a class="btn btn-primary" href="efficacy-report.html?demo=1">See a sample report</a>
      <a class="btn btn-secondary" href="#walkthrough">Request a walkthrough</a>
    </div>
    <p class="fine mono" style="color:var(--ash);letter-spacing:.02em">NORMED ON 9,232 FATHERS &nbsp;&middot;&nbsp; NCF, SINCE 1990 &nbsp;&middot;&nbsp; VERIFY A SERIAL IN 10 SECONDS</p>
  </div>
  <div class="artifact">
    <div class="artifact-tab">WHAT YOUR FUNDER RECEIVES</div>
    <div class="artifact-doc">
      <div class="row between" style="align-items:baseline;margin-bottom:2px"><b style="font-size:15px">Keystone Efficacy Report</b><span class="chip" style="font-size:10px">SAMPLE</span></div>
      <p class="fine" style="color:var(--ash);margin-bottom:14px">Sample Fatherhood Program &middot; one page per cohort</p>
      <table class="artifact-table">
        <tr><th>Cohort</th><th>Fathers</th><th>Completed</th><th>Baseline</th><th>Latest</th><th>Movement</th></tr>
        <tr><td>Spring cohort A</td><td>24</td><td>19</td><td>58.4</td><td>71.2</td><td class="mv">+12.8</td></tr>
        <tr><td>Spring cohort B</td><td>18</td><td>13</td><td>61.0</td><td>69.5</td><td class="mv">+8.5</td></tr>
        <tr><td>Intake, no program</td><td>31</td><td>0</td><td>55.9</td><td>&mdash;</td><td>baseline only</td></tr>
      </table>
      <p class="fine" style="color:var(--ash);margin-top:12px">Individual fathers are never shown. Cohort aggregates only. <a class="link" href="efficacy-report.html?demo=1">Open the full sample &rarr;</a></p>
    </div>
  </div>
</div></section>

<section class="tight" style="padding:36px 0;background:var(--coal)"><div class="container">
  <div class="eyebrow" style="margin-bottom:12px">FIND YOUR FIT</div>
  <h2 class="d-28" style="margin-bottom:18px">Every kind of program lands here. Start where you live.</h2>
  <div class="grid-3">
    <a class="fit-card" href="#residential"><b>Residential &amp; recovery programs</b><span>Cohorts that fit your episode. Baseline at intake, a certificate presented before discharge.</span><i>&rarr;</i></a>
    <a class="fit-card" href="#reentry"><b>Reentry &amp; alternative sentencing</b><span>Baseline at intake, movement by release. The floor is never nothing.</span><i>&rarr;</i></a>
    <a class="fit-card" href="#courts"><b>Courts &amp; probation</b><span>Order the course by name. Verify a serial in ten seconds.</span><i>&rarr;</i></a>
    <a class="fit-card" href="#programs"><b>Fatherhood programs</b><span>Keep the curriculum you trust. We make it provable.</span><i>&rarr;</i></a>
    <a class="fit-card" href="groups.html"><b>Churches, groups &amp; circles</b><span>Small groups of men, measured and moving together.</span><i>&rarr;</i></a>
    <a class="fit-card" href="employers.html"><b>Employers</b><span>A benefit men actually use, with proof it worked.</span><i>&rarr;</i></a>
  </div>
</div></section>

<section class="tight" id="programs"><div class="container split" style="gap:48px">
  <div>
    <div class="eyebrow" style="margin-bottom:12px">FATHERHOOD PROGRAMS</div>
    <h2 class="d-28" style="margin-bottom:12px">Keep the curriculum you trust. We make it provable.</h2>
    <p class="small" style="color:var(--ash);max-width:56ch">Your program stays exactly as you run it. We add the measurement spine underneath: every father baselines at intake through your join link, retakes at exit, and your Efficacy Report writes itself, one page per cohort, benchmarked against 9,232 fathers. Concierge-first means we run your first cohort with you: codes minted, men enrolled, the report in your funder&rsquo;s hands.</p>
  </div>
  <div class="card" style="padding:26px 28px;align-self:start">
    <p class="small" style="margin-bottom:16px"><b>Twenty minutes gets you live.</b> Your program, your funder&rsquo;s report, on the call.</p>
    <div class="row wrap" style="gap:10px"><a class="btn btn-primary btn-sm" href="#walkthrough">Request a walkthrough</a><a class="btn btn-secondary btn-sm" href="mailto:Team@Fathers.com?subject=Our%20fatherhood%20program%20on%20the%20Standard">Write us</a></div>
  </div>
</div></section>

<section class="tight" id="residential"><div class="container split" style="gap:48px">
  <div>
    <div class="eyebrow" style="margin-bottom:12px">RESIDENTIAL &amp; RECOVERY PROGRAMS</div>
    <h2 class="d-28" style="margin-bottom:12px">Built to fit a residential episode.</h2>
    <p class="small" style="color:var(--ash);max-width:56ch">Baseline in the first week. Weekly cohort sessions led by your own staff as Certified Facilitators. Completion and the certificate ceremony before discharge, and the man&rsquo;s account is his: his plan and his record follow him home, because the work does not end when the placement does. Your program never appears on his public record; you see cohort movement, never a man&rsquo;s private answers, and no clinical information is ever stored here.</p>
  </div>
  <div class="card" style="padding:26px 28px;align-self:start">
    <p class="small" style="margin-bottom:16px"><b>Fits inside a 120-day placement</b> with margin, or a shorter stay with aftercare handoff.</p>
    <div class="row wrap" style="gap:10px"><a class="btn btn-primary btn-sm" href="#walkthrough">Request a walkthrough</a><a class="btn btn-secondary btn-sm" href="mailto:Team@Fathers.com?subject=Residential%20program%20certification">Write us</a></div>
  </div>
</div></section>

<section class="tight" id="certification"><div class="container">
  <div class="eyebrow" style="margin-bottom:12px">WHAT CERTIFICATION MEANS</div>
  <h2 class="d-28" style="margin-bottom:18px">Two credentials carry the standard. Both are published, renewable, and revocable.</h2>
  <div class="grid-2" style="gap:24px">
    <div class="card" style="padding:28px">
      <div class="eyebrow brass" style="margin-bottom:12px">CERTIFIED ORGANIZATION</div>
      <p class="small" style="color:var(--ash);margin-bottom:14px">A site that meets the published standard: Certified Facilitators on staff, fidelity to the course structure, baseline and exit measurement on every cohort, honest reporting. Annual. Listed in the public registry. The Efficacy Report is a benefit of certification, not a separate product.</p>
      <p class="fine mono">$1,500 per site, per year &middot; unlimited cohorts &middot; launch pricing pends partner interviews</p>
    </div>
    <div class="card" style="padding:28px">
      <div class="eyebrow brass" style="margin-bottom:12px">CERTIFIED FACILITATOR</div>
      <p class="small" style="color:var(--ash);margin-bottom:14px">A person credentialed to lead men through the courses: facilitator training, an exam, and a supervised first cohort, with annual renewal. The credential belongs to the person and travels with them. Listed in the public registry with current status.</p>
      <p class="fine mono">$349 initial &middot; $99 annual renewal &middot; launch pricing pends partner interviews</p>
      <p style="margin-top:14px"><a class="link brass" href="facilitators.html">Become a Certified Facilitator &rarr;</a></p>
    </div>
  </div>
  <p class="fine" style="margin-top:16px;color:var(--ash)">The men pay nothing, ever. Certification criteria are published in full, and organizations running non-NCF curricula can certify against the same measurement standard. The standard is the spine, not the syllabus.</p>
</div></section>

<section class="tight" id="reentry"><div class="container split" style="gap:48px">
  <div>
    <div class="eyebrow" style="margin-bottom:12px">REENTRY &amp; ALTERNATIVE SENTENCING</div>
    <h2 class="d-28" style="margin-bottom:12px">Baseline at intake. Movement by release. The floor is never nothing.</h2>
    <p class="small" style="color:var(--ash);max-width:56ch">You already intake men; start measuring the day they arrive, program or no program. Cohorts persist across facilities and time, so a man&rsquo;s movement follows him. When your agency links its outcome records, the Recidivism Overlay switches on: Keystone movement set against reoffense, completers versus non-completers, the number a reentry grant lives or dies on.</p>
  </div>
  <div class="card" style="padding:26px 28px;align-self:start">
    <p class="small" style="margin-bottom:16px"><b>Runs inside your intake.</b> No curriculum required to start.</p>
    <div class="row wrap" style="gap:10px"><a class="btn btn-primary btn-sm" href="#walkthrough">Request a walkthrough</a><a class="btn btn-secondary btn-sm" href="mailto:Team@Fathers.com?subject=Reentry%20measurement%20on%20the%20Standard">Write us</a></div>
  </div>
</div></section>

<section style="background:#0B0B0B;color:#F5F1E8;padding:64px 0"><div class="container split" style="gap:56px">
  <div>
    <div class="eyebrow" style="color:#C9A227;margin-bottom:14px">THE SHIFT</div>
    <h2 class="d-36" style="color:#F5F1E8">Attendance was the old currency. Movement is the new one.</h2>
  </div>
  <div class="grid-2" style="gap:32px">
    <div><p class="fine mono" style="color:#8A8A8A;margin-bottom:8px">THE OLD WAY</p><p class="small" style="color:#C7C2B8">Sign-in sheets, satisfaction surveys, and a renewal that lives or dies on a story. Every program says it works. None can show it.</p></div>
    <div><p class="fine mono" style="color:#C9A227;margin-bottom:8px">THE STANDARD</p><p class="small" style="color:#F5F1E8">Baseline and exit on a validated instrument. Movement per cohort, benchmarked against 9,232 fathers. A renewal that is a number.</p></div>
  </div>
</div></section>

<section class="tight" style="padding:56px 0 20px"><div class="container" style="max-width:900px;text-align:center">
  <h2 class="d-36">Every father measured. Every program provable. Every credential trusted on sight.</h2>
</div></section>

<section class="tight"><div class="container">
  <div class="grid-3" style="gap:24px">
    <div class="card" style="padding:26px 28px"><p class="fine mono" style="color:var(--ember);margin-bottom:10px">01 &middot; MEASURE</p><h3 style="margin-bottom:8px">One join link tags every man.</h3><p class="small" style="color:var(--ash)">The Keystone Profile at intake: 128 items, 26 scales, about twenty minutes. Four dimensions on every man, zero program required.</p></div>
    <div class="card" style="padding:26px 28px"><p class="fine mono" style="color:var(--ember);margin-bottom:10px">02 &middot; TRAIN</p><h3 style="margin-bottom:8px">Keep the program you trust.</h3><p class="small" style="color:var(--ash)">We make it provable. Or deploy ours: the flagship course is live today, free to every man, with two more courses in development. Your staff lead it as Certified Facilitators.</p></div>
    <div class="card" style="padding:26px 28px"><p class="fine mono" style="color:var(--ember);margin-bottom:10px">03 &middot; PROVE</p><h3 style="margin-bottom:8px">The report and the credential.</h3><p class="small" style="color:var(--ash)">The Efficacy Report, one page per cohort. Certificates of Completion presented by your facilitators, serialed, and verified at fathers.com/verify in ten seconds.</p></div>
  </div>
</div></section>

<section class="band tight"><div class="container split">
  <div>
    <div class="eyebrow brass" style="margin-bottom:14px">AVAILABLE NOW</div>
    <h2 class="d-36" style="font-size:32px">The Efficacy Report.</h2>
    <p style="color:var(--ash);margin:16px 0 18px;max-width:52ch">One page per cohort: how many fathers started, how many finished, where they began on the four dimensions, where they ended, and the movement in between, benchmarked against the national norm. Individual fathers are never shown. Aggregates only.</p>
    <p style="color:var(--ash);margin:0 0 26px;max-width:52ch">This is the document that turns a grant renewal from a story into a number.</p>
    <div class="row wrap"><a class="btn btn-primary" href="efficacy-report.html?demo=1">See a sample report</a><a class="btn btn-secondary" href="#walkthrough">Request yours</a></div>
  </div>
  <div class="card" style="padding:32px">
    <div class="eyebrow" style="margin-bottom:16px">WHAT A FUNDER SEES</div>
    <div class="stack-16">
      <div class="check"><span class="checkmark">&check;</span><span>Baseline and exit scores on the four Keystone dimensions</span></div>
      <div class="check"><span class="checkmark">&check;</span><span>Cohort movement, benchmarked against 9,232 fathers</span></div>
      <div class="check"><span class="checkmark">&check;</span><span>Completion rates that hold up to an auditor</span></div>
      <div class="check"><span class="checkmark">&check;</span><span>Outcome overlays when your agency links its data</span></div>
    </div>
  </div>
</div></section>

<section><div class="container">
  <h2 class="d-28" style="margin-bottom:8px">Outcome overlays: the same spine, in the language you answer to.</h2>
  <p style="color:var(--ash);margin:0 0 32px;max-width:62ch">Movement is what we measure. Outcomes are what you are accountable for. When the responsible agency links its outcome records to your cohorts through the secure intake, the overlay switches on. Until then, the report says so honestly.</p>
  <div class="grid-3">
    <div class="card" style="padding:28px"><div class="eyebrow brass" style="margin-bottom:12px">REENTRY &amp; ALTERNATIVE SENTENCING</div><h3 style="margin-bottom:8px">The Recidivism Overlay</h3><p class="small" style="color:var(--ash)">Keystone movement set against reoffense records, completers versus non-completers, per cohort. The number a reentry grant lives or dies on.</p></div>
    <div class="card" style="padding:28px"><div class="eyebrow brass" style="margin-bottom:12px">CHILD SUPPORT</div><h3 style="margin-bottom:8px">The Collection Overlay</h3><p class="small" style="color:var(--ash)">Engagement set against payment compliance. Engaged fathers pay. Show the connection in your own caseload.</p></div>
    <div class="card" style="padding:28px"><div class="eyebrow brass" style="margin-bottom:12px">RESIDENTIAL &amp; RECOVERY</div><h3 style="margin-bottom:8px">The Continuity Overlay</h3><p class="small" style="color:var(--ash)">Completion and aftercare engagement set against program retention and discharge outcomes, per cohort, with no clinical data ever stored on this platform. The number a program renewal stands on.</p></div>
  </div>
</div></section>

<section id="courts" class="band tight"><div class="container split">
  <div>
    <div class="eyebrow" style="margin-bottom:14px">FOR COURTS AND PROBATION</div>
    <h2 class="d-28" style="margin-bottom:8px">Order the class by name. Verify in ten seconds.</h2>
    <p style="color:var(--ash);max-width:52ch">Fathering Fundamentals is orderable by name today: identity confirmed at enrollment, hours logged not claimed, a final at eighty percent. Completion is confirmed at fathers.com/verify with the serial on the Certificate of Completion. No account, no phone call, no paperwork chase. Coming Home Present and Steady Under Pressure, built for referral, are in development; waitlist your caseload and they train first.</p>
  </div>
  <div class="card" style="padding:32px">
    <div class="eyebrow" style="margin-bottom:16px">FOR THE MAN YOU REFER</div>
    <p class="small" style="color:var(--ash)">He starts free with the Keystone Profile, trains the course you name, and leaves with a document that opens doors instead of a checkbox that closes them. He pays nothing at any step.</p>
  </div>
</div></section>

<section class="band tight"><div class="container">
  <h2 class="d-28" style="margin-bottom:8px">No program yet? The floor is never nothing.</h2>
  <p style="color:var(--ash);margin:0 0 32px;max-width:60ch">You already intake men. Start measuring today and switch the rest on when you are ready.</p>
  <div class="grid-3">
    <div class="card" style="padding:28px"><div class="eyebrow" style="margin-bottom:12px">STEP ONE</div><h3 style="margin-bottom:8px">Measure at the door.</h3><p class="small" style="color:var(--ash)">Run the Keystone Profile at intake. A validated engagement baseline on every man, zero program required.</p></div>
    <div class="card" style="padding:28px"><div class="eyebrow" style="margin-bottom:12px">STEP TWO</div><h3 style="margin-bottom:8px">Route to what works.</h3><p class="small" style="color:var(--ash)">Each profile points to the rated program that fits him. We become your diagnostic and referral layer.</p></div>
    <div class="card" style="padding:28px"><div class="eyebrow" style="margin-bottom:12px">STEP THREE</div><h3 style="margin-bottom:8px">Deploy ours in a day.</h3><p class="small" style="color:var(--ash)">The assessment, three courses (presence, steadiness, coming home), the ninety-day plan, the Certificate of Completion. Switched on, not built.</p></div>
  </div>
</div></section>

<section><div class="container split">
  <div>
    <div class="eyebrow" style="margin-bottom:14px">DEPLOY AT SCALE</div>
    <h2 class="d-36" style="font-size:32px">One join link. Every man tagged to your cohort.</h2>
    <p style="color:var(--ash);margin:16px 0 18px;max-width:52ch">A facility, a caseload, a congregation: share one link and every man who enters it is assessed under your organization, program, and cohort. The report builds itself as they move. Leadership sees cohort movement, never a man&rsquo;s private answers.</p>
    <p style="color:var(--ash);max-width:52ch">Concierge-first: we run your first cohort with you. Codes minted, facilitators credentialed, men enrolled, the report in your funder&rsquo;s hands. What ships today is real: the Keystone Profile, the free flagship course, and the ninety-day plan.</p>
  </div>
  <div class="card" style="padding:32px" id="walkthrough">
    <div class="eyebrow" style="margin-bottom:16px">REQUEST A WALKTHROUGH</div>
    <p class="small" style="color:var(--ash);margin-bottom:20px">Twenty minutes. Your program, your funder&rsquo;s report, live. We will set up your join link on the call.</p>
    <form class="stack-16" data-lead="org-inquiry" data-done="Received. We will reach out to schedule your walkthrough.">
      <input class="input" name="org" required placeholder="Organization name">
      <input class="input" name="email" type="email" required placeholder="Work email">
      <button class="btn btn-primary">Request a walkthrough</button>
    </form>
    <p class="fine" style="margin-top:14px">Already on the standard? <a class="link ash" href="efficacy-report.html">Open your Efficacy Report</a>.</p>
  </div>
</div></section>

<section style="background:#0B0B0B;color:#F5F1E8;padding:56px 0"><div class="container" style="text-align:center">
  <div class="eyebrow" style="color:#C9A227;margin-bottom:14px">THE SPINE</div>
  <h2 class="d-36" style="color:#F5F1E8;margin-bottom:22px">Measure. Train. Prove.</h2>
  <div class="row wrap" style="gap:12px;justify-content:center">
    <a class="btn btn-primary" href="efficacy-report.html?demo=1">See a sample report</a>
    <a class="btn btn-secondary" style="color:#F5F1E8;border-color:rgba(255,255,255,.4)" href="#walkthrough">Get on the Standard</a>
  </div>
  <p class="fine" style="color:#8A8A8A;margin-top:22px">Also built for: <a class="link" href="groups.html" style="color:#C7C2B8">Groups &amp; Circles</a> &nbsp;&middot;&nbsp; <a class="link" href="facilitators.html" style="color:#C7C2B8">Certified Facilitators</a> &nbsp;&middot;&nbsp; <a class="link" href="employers.html" style="color:#C7C2B8">Employers</a></p>
</div></section>
''')

PAGES['facilitators.html'] = dict(title='Become a Certified Facilitator', desc='The credential for the person leading men through the work: training, an exam, a supervised first cohort, annual renewal, and a public registry. It belongs to you and travels with you.', active='For Organizations', mode='public', body='''
<section class="tight" style="padding:52px 0 44px"><div class="container split" style="align-items:center;gap:56px">
  <div>
    <div class="eyebrow" style="margin-bottom:14px">CERTIFICATION FOR FACILITATORS</div>
    <h1 class="d-48" style="margin-bottom:16px">Become a Certified Facilitator.</h1>
    <p style="color:var(--ash);max-width:52ch;margin-bottom:24px">The men do the work. You carry the standard. The NCF Certified Facilitator credential says you were trained, examined, and supervised through a real cohort, and that your status is current and publicly checkable. It belongs to you, not your employer, and it travels with you.</p>
    <div class="row wrap" style="gap:12px;margin-bottom:22px">
      <a class="btn btn-primary" href="mailto:Team@Fathers.com?subject=Certified%20Facilitator%20credential">Start the conversation</a>
      <a class="btn btn-secondary" href="verify.html">Check a facilitator&rsquo;s status</a>
    </div>
    <p class="fine mono" style="color:var(--ash);letter-spacing:.02em">$349 INITIAL &nbsp;&middot;&nbsp; $99 ANNUAL RENEWAL &nbsp;&middot;&nbsp; LAUNCH PRICING PENDS PARTNER INTERVIEWS</p>
  </div>
  <div class="card" style="padding:32px">
    <div class="eyebrow" style="margin-bottom:16px">THE PATH</div>
    <div class="stack-16">
      <div class="check"><span class="checkmark">&check;</span><span><b>The facilitator course.</b> How the courses are built, how cohorts run, and where facilitation goes wrong.</span></div>
      <div class="check"><span class="checkmark">&check;</span><span><b>The exam.</b> Pass it or you are not certified. There is no attendance credential here.</span></div>
      <div class="check"><span class="checkmark">&check;</span><span><b>A supervised first cohort.</b> You lead, we review. The credential is granted when the cohort completes.</span></div>
      <div class="check"><span class="checkmark">&check;</span><span><b>Annual renewal.</b> A code of conduct, continuing standards, and a registry that shows your current status.</span></div>
    </div>
  </div>
</div></section>

<section class="band tight"><div class="container">
  <div class="eyebrow" style="margin-bottom:12px">WHO THIS IS FOR</div>
  <h2 class="d-28" style="margin-bottom:18px">The people already in the room.</h2>
  <div class="grid-3">
    <div class="card" style="padding:26px 28px"><b>Program staff</b><p class="small" style="margin-top:8px;color:var(--ash)">Case managers, counselors, and chaplains inside residential, recovery, and reentry programs. Your organization certifies; you carry the credential.</p></div>
    <div class="card" style="padding:26px 28px"><b>Church and community leaders</b><p class="small" style="margin-top:8px;color:var(--ash)">Men&rsquo;s ministry leaders and mentors who already gather men. Certification turns a good group into a measured cohort.</p></div>
    <div class="card" style="padding:26px 28px"><b>Men who did the work</b><p class="small" style="margin-top:8px;color:var(--ash)">Completers with a Certificate of Completion who want to lead the next cohort. The best facilitators usually started in the chairs.</p></div>
  </div>
</div></section>

<section class="tight"><div class="container split" style="gap:48px">
  <div>
    <div class="eyebrow" style="margin-bottom:12px">WHY IT IS STRICT</div>
    <h2 class="d-28" style="margin-bottom:12px">A registry only means something if names can come off it.</h2>
    <p class="small" style="color:var(--ash);max-width:56ch">Most curricula in this field sell a kit and an optional webinar and call the buyer trained. We do not. Certification here is examined, supervised, renewed annually, and revocable for cause, with status published in the registry. That is more work for you and for us. It is also the only reason a court, a funder, or a program director can trust the title on sight.</p>
  </div>
  <div class="card" style="padding:26px 28px;align-self:start">
    <p class="small" style="margin-bottom:16px"><b>Organizations:</b> facilitator credentialing is part of site certification. Certify the org, credential the staff, run unlimited cohorts.</p>
    <a class="btn btn-secondary btn-sm" href="organizations.html#certification">See organization certification</a>
  </div>
</div></section>
''')

PAGES['gatherings.html'] = dict(title='Gatherings', desc='Fathers, in real life. Events that bring men, mentors, and the people who lead them into the same room.', active='Gatherings', mode='public', body='''
<header class="hero"><div class="container" style="max-width:820px">
  <div class="eyebrow" style="margin-bottom:18px">GATHERINGS</div>
  <h1 class="d-48" style="font-weight:700;letter-spacing:-.02em">Fathers, in real life.</h1>
  <p class="lead" style="margin:22px 0 8px">Where the Standard meets in person. Presence is not only trained on a screen. We gather fathers, mentors, and the people who lead them, to learn, to be sharpened, and to stand together.</p>
</div></header>

<section class="band tight"><div class="container split">
  <div>
    <h2 class="d-28">Be first to know.</h2>
    <p class="small" style="color:var(--ash);margin-top:10px;max-width:44ch">We are starting with one or two flagship gatherings. Tell us where you are and we will tell you when one is near you.</p>
  </div>
  <div>
    <form class="stack-16" data-lead="gatherings" data-done="You are on the list. We will tell you when a gathering is near you.">
      <input class="input" name="city" placeholder="City or region">
      <input class="input" name="email" type="email" required placeholder="Email address">
      <button class="btn btn-primary">Notify me</button>
    </form>
    <p class="fine" style="margin-top:12px">Want to bring a gathering to your church, base, or city? Same form. Say so when we reply.</p>
  </div>
</div></section>
''')

# ================================================== about.html
PAGES['about.html'] = dict(title='About the National Center for Fathering', desc='NCF measures men, trains them free, certifies the organizations and facilitators who lead them, and convenes the field.', active='', mode='public', body='''
<header class="hero"><div class="container" style="max-width:860px">
  <div class="eyebrow" style="margin-bottom:18px">ABOUT NCF</div>
  <h1 class="d-48" style="font-weight:700;letter-spacing:-.02em">The trusted third party for fatherhood.</h1>
  <p class="lead" style="margin:22px 0 8px">The National Center for Fathering measures men, trains them at no cost, certifies the organizations and facilitators who lead them, and convenes the field. We publish one standard and hold everyone to it, including ourselves: our own courses are measured, reported, and rated the same way anyone else&rsquo;s are.</p>
</div></header>

<section class="band tight"><div class="container split">
  <div>
    <h2 class="d-36" style="font-size:32px">Built on three decades of research.</h2>
    <p style="color:var(--ash);margin:16px 0 18px;max-width:52ch">NCF was founded by Dr. Ken Canfield, whose research and books on fathering have guided a generation of men. The Keystone Father Profile grows directly out of that work: four dimensions, normed on 9,232 fathers, made practical.</p>
    <p style="color:var(--ash);max-width:52ch">Fathers.com is the home of that standard: the free Profile for any man, the free courses to grow it, the Certificate of Completion that proves the work, the Certified Organization and Certified Facilitator credentials that carry it, and the reporting that shows funders and agencies whether men are changing.</p>
  </div>
  <div class="card" style="padding:32px">
    <div class="eyebrow" style="margin-bottom:16px">WHAT WE DO</div>
    <div class="stack-16">
      <div class="check"><span class="checkmark">&check;</span><span><b>Measure.</b> The Keystone Profile, free for every man.</span></div>
      <div class="check"><span class="checkmark">&check;</span><span><b>Train.</b> Three courses, free to the men who take them.</span></div>
      <div class="check"><span class="checkmark">&check;</span><span><b>Certify.</b> Organizations and facilitators, against a published standard, with a public registry.</span></div>
      <div class="check"><span class="checkmark">&check;</span><span><b>Convene.</b> Gatherings that bring the field into one room.</span></div>
    </div>
  </div>
</div></section>

<section><div class="container" style="max-width:820px">
  <p class="small" style="color:var(--ash)">Fathers.com is a program of the National Center for Fathering, a 501(c)(3) nonprofit. PO Box 996, Tontitown, AR 72770. <a class="link" href="mailto:Team@Fathers.com">Team@Fathers.com</a></p>
</div></section>
''')

# ================================================== research.html
PAGES['research.html'] = dict(title='The research behind the Keystone Profile', desc='Four dimensions. Normed on 9,232 fathers. A versioned instrument, scored against published norms.', active='', mode='public', body='''
<header class="hero"><div class="container" style="max-width:860px">
  <div class="eyebrow" style="margin-bottom:18px">RESEARCH</div>
  <h1 class="d-48" style="font-weight:700;letter-spacing:-.02em">The instrument behind the standard.</h1>
  <p class="small" style="color:var(--ash);margin-top:14px;max-width:56ch">The instrument is versioned. Norms are published. Methods are shown. Rate us the way we rate programs.</p>
  <p class="lead" style="margin:22px 0 8px">The Keystone Father Profile is a validated, versioned instrument built from Dr. Ken Canfield's research and normed on 9,232 fathers. It is the spine of everything on this platform.</p>
</div></header>

<section class="band tight"><div class="container">
  <h2 class="d-28" style="margin-bottom:8px">Four dimensions decide the kind of father you are.</h2>
  <p style="color:var(--ash);margin:0 0 32px;max-width:60ch">Every score, plan, certificate, and report on this platform is built from movement on these four.</p>
  <div class="grid-2">
    <div class="card" style="padding:28px"><h3 style="margin-bottom:8px">Involvement</h3><p class="small" style="color:var(--ash)">The time and attention a father actually gives, not the time he intends to give.</p></div>
    <div class="card" style="padding:28px"><h3 style="margin-bottom:8px">Consistency</h3><p class="small" style="color:var(--ash)">Whether a father shows up the same way on ordinary days, not only on the big ones.</p></div>
    <div class="card" style="padding:28px"><h3 style="margin-bottom:8px">Awareness</h3><p class="small" style="color:var(--ash)">How well a father knows his actual child: what they fear, love, and carry right now.</p></div>
    <div class="card" style="padding:28px"><h3 style="margin-bottom:8px">Nurturance</h3><p class="small" style="color:var(--ash)">The warmth a child can feel, expressed so the child receives it.</p></div>
  </div>
</div></section>

<section><div class="container split">
  <div>
    <h2 class="d-36" style="font-size:32px">How scoring works.</h2>
    <p style="color:var(--ash);margin:16px 0 18px;max-width:52ch">The full instrument is sectioned and resumable, scored against published norms, and versioned so every result states exactly which instrument produced it. Your answers produce scale scores, an overall standing, your strongest scale, and the gap your plan is built from.</p>
    <p style="color:var(--ash);max-width:52ch">Your results belong to you. We never share an individual father's results. Programs see cohort movement, never a man's private answers.</p>
  </div>
  <div>
    <a class="btn btn-primary" href="profile.html">Take the Profile</a>
    <p class="fine" style="margin-top:12px">Free. About twenty minutes. Private.</p>
  </div>
</div></section>

<section class="band tight"><div class="container" style="max-width:860px">
  <div class="eyebrow" style="margin-bottom:12px">IN DEVELOPMENT</div>
  <h2 class="d-28" style="margin-bottom:8px">The Keystone Manhood Profile.</h2>
  <p style="color:var(--ash);margin:0 0 14px;max-width:62ch">The Manhood Track instrument mirrors the Father Profile architecture exactly: 128 items, 26 scales, identical response formats and scoring, so the two tracks are measured with equal weight. Its four dimensions are Presence, Discipline, Respect, and Service, grounded in strengths-based research on prosocial masculinity, self-discipline, and contribution.</p>
  <p style="color:var(--ash);margin:0;max-width:62ch">The draft item bank is complete and under psychometric review. It deploys only after sign-off and carries no norm-referenced claims until a norming study supports them. That is the same rule we hold every instrument to, including our own.</p>
</div></section>
''')

# ================================================== efficacy-report.html
PAGES['efficacy-report.html'] = dict(title='The Efficacy Report', desc='Cohort movement on the Keystone Father Profile, benchmarked against 9,232 fathers, in the format funders ask for.', active='For Organizations', mode='public', body='''
<section class="tight" style="padding-top:56px"><div class="container" style="max-width:980px">
  <div class="row between wrap" style="align-items:flex-end;margin-bottom:8px">
    <div>
      <div class="eyebrow brass" style="margin-bottom:12px">THE EFFICACY REPORT</div>
      <h1 class="d-36">Proof, in one page.</h1>
    </div>
    <div class="row" style="gap:10px">
      <select class="input" id="reportOrg" hidden style="max-width:260px"></select>
      <button class="btn btn-secondary btn-sm" data-print>Print</button>
    </div>
  </div>
  <p style="color:var(--ash);margin:0 0 28px;max-width:62ch">Movement on the four Keystone dimensions, per cohort, benchmarked against the national norm. This page is the deliverable: print it, attach it, submit it.</p>
  <div id="reportRoot"></div>
  <p class="fine" style="margin-top:22px">Not on the standard yet? <a class="link" href="organizations.html">Start here</a>. Methodology: <a class="link ash" href="research.html">the research</a>.</p>
  <p class="fine" style="margin-top:10px">Send this page to your funder. It is designed to be forwarded. <a class="link" href="mailto:?subject=Keystone%20Efficacy%20Report%20sample&amp;body=The%20report%20our%20program%20delivers%3A%20https%3A%2F%2Ffathers-com-platform.vercel.app%2Fefficacy-report.html%3Fdemo%3D1">Email the sample &rarr;</a></p>
</div></section>
<style>@media print{.nav,footer,.btn,select{display:none!important}body{background:#fff;color:#000}}</style>
<script src="assets/js/report.js"></script>
''')

# ================================================== WRITER
if __name__ == '__main__':
    out = os.path.dirname(os.path.abspath(__file__))
    if not SHOW_MILITARY:
        for dead in MILITARY_PAGES:
            dp = os.path.join(out, dead)
            if os.path.exists(dp):
                os.remove(dp)
                print('removed (military dark)', dead)
    for fname, p in PAGES.items():
        if not SHOW_MILITARY and fname in MILITARY_PAGES:
            continue
        FORCED_THEME = {'organizations.html': "'light'", 'index.html': "'dark'", 'profile.html': "'dark'", 'stories.html': "'dark'", 'certificates.html': "'dark'", 'enroll.html': "'dark'", 'class.html': "'dark'", 'course.html': "'dark'", 'player.html': "'dark'", 'checkout.html': "'dark'", 'certificate.html': "'dark'", 'voice.html': "'dark'", 'share.html': "'dark'"}
        theme_js = FORCED_THEME.get(fname, 'localStorage.getItem("fc_theme")||"dark"')
        html = HEAD.format(title=p['title'], desc=p['desc'], meta=social_meta(fname, p['title'], p['desc']), THEME=theme_js)
        if p.get('nochrome'):
            html += p['body']
            html += '\n<script src="assets/js/config.js"></script>\n<script src="assets/js/supabase-client.js"></script>\n<script src="assets/js/app.js"></script>\n'
            if fname == 'profile.html':
                html += '<script src="assets/js/keystone-data.js"></script>\n<script src="assets/js/keystone-full.js"></script>\n<script src="assets/js/keystone-ui.js"></script>\n'
        else:
            html += nav(p.get('active',''), p.get('mode','public'))
            html += p['body']
            html += FOOT
            if p.get('auth'):
                html = html.replace('<body>', '<body data-auth="required">', 1)
        html += '</body>\n</html>\n'
        with open(os.path.join(out, fname), 'w') as f:
            f.write(html)
        print('wrote', fname)
